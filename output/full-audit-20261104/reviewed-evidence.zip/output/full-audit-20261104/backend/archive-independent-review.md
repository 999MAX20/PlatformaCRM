# Independent review: clean-archive selection

Confirmed **P2 packaging confidentiality defect**, conditional on running this helper
from a checkout containing private artifacts. Potential impact is high if such an
archive is subsequently shared. Neither an actual private archive nor external
disclosure is established by this evidence.

I independently read the complete current `scripts/make_clean_archive.sh`, the
synthetic generator `../archive_probe.py` and its result `../archive-probe.json`.
No helper, shell probe, archive extraction or security experiment was executed in
this review; no real secret or private file contents were inspected.

## Source and applicability

`scripts/make_clean_archive.sh:13–50` copies the entire checkout with actual rsync
selection rules. It excludes `.env`, `.env.*` and the exact `db.sqlite3` basename,
but does not exclude `output/` or `.playwright-cli/`. Those patterns do not exclude
`qr-issuer.env`, `backup-before.sqlite3` or browser-session JSON. `.gitignore` is not
consulted by this command. Line52 archives the resulting selected tree without an
additional sanitization step.

This is a reachable operator command, not an automatic upload or unauthenticated
endpoint. The unsafe selection applies when the named kinds of files exist under
the source tree and the command runs successfully. A minimal source-only checkout
without such files need not leak anything. The real checkout's sensitive-file
contents and whether an affected archive was ever sent remain unproven.

## Existing synthetic evidence and limits

The generator's lines7–22 create a unique disposable Linux fixture from explicit
synthetic strings. Only the archive helper source is copied from the real checkout.
Its input selection is performed by installed rsync. The recorded member list
includes all four deliberate markers:

- `output/account-security-backups/qr-issuer.env`
- `output/backup-before.sqlite3`
- `output/browser/storage-state.json`
- `.playwright-cli/session.json`

The complete recorded member list excludes the four controls `.env`, `.env.private`,
`db.sqlite3` and `.venv/example.py`. Generator lines38–40 explicitly assert the
`.env`/`db.sqlite3` exclusions and all four included markers; the other exclusions are
independently visible in the member list rather than separately asserted.

`zip` was unavailable. Generator lines24–32 provide a Python standard-library zip
shim that archives regular files already selected by rsync. This is adequate to
corroborate the four regular-file selection failures, but does **not** certify the
native zip executable, symlink handling, permissions, unusual filenames or complete
archive-format equivalence. The selected tree, not compression semantics, is the
root cause.

The helper copy is normalized from CRLF to LF in the disposable fixture. The
receipt records successful subprocess exit0 and the generator checks that status.
The receipt's initial CRLF/exit2 attempt is hard-coded historical metadata in the
generator; no separate raw first-attempt stdout/stderr log was found among the
archive-probe artifacts. I therefore do not independently certify that initial
attempt from the current generator. Its absence does not weaken the current
source-pattern analysis or recorded final selected-member list. The generator
captures subprocess output but persists only the result JSON; it prints the same
result for the calling tool. No second raw transcript is claimed.

## Recommendation and acceptance

Use an explicit deliverable/source manifest or allowlist, with deliberate inclusion
of approved example configs. Exclude runtime output, browser/session state, backups
and key material regardless of innocuous extensions; a growing basename denylist
alone is fragile. This recommendation does not authorize modifying or deleting
existing private artifacts.

Acceptance for a future fix:

1. A disposable fixture containing these four markers, nested backup/key/session
   variants and normal source/example configs produces no private marker members
   while retaining intended distributable files.
2. Inspect the final archive member list, not only rsync exit status. Exercise the
   actual supported rsync and native zip tools; retain any shim as a separately
   limited test, not native-tool acceptance.
3. Preserve failure propagation and safe temporary-tree cleanup. Do not run the
   regression against the working checkout's real private data.

No owner policy decision is needed to establish that a clean distributable should
exclude auth/session secrets and database backups. The exact intended source
manifest can be chosen during remediation without claiming all local files are
safe to publish. No fix or publication occurred in this review.

## Exact reviewed evidence

- `scripts/make_clean_archive.sh:13–52`, SHA256
  `6fd264bbfce5f7042125e11982389bdeefc66629c5ee5e6fed6d93ee8476ff21`
  (matches the probe's source hash).
- `output/full-audit-20261104/archive_probe.py:7–43`, SHA256
  `672aac2afd6535f5cc3dd9de3f9bbe3faab9155df15b701138677f83ea6aae75`.
- `output/full-audit-20261104/archive-probe.json`, SHA256
  `d7a79736147b0b37439c1162842219ae2fde0626bb5d4bc9fc2a3438a049c408`.

Boundary: canonical local source snapshot d27044b1 plus preserved WIP; independent
read-only source/evidence review, not a second runtime reproduction or deployment
assessment.
