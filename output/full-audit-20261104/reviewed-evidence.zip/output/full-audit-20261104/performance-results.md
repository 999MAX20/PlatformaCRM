# Extended isolated load evidence

Scope: unchanged canonical source d27044b1 plus recorded WIP; Windows Django
development server, disposable PostgreSQL 17/Redis, 1,000 synthetic rows per
domain and two tenants. This measures this fixture/environment, not production
capacity, a service-level objective or a 24-hour leak test.

Initial burst: 10 concurrent clients, 50 attempts, 40 HTTP 200 and 10 Clients
request deadline failures (10 seconds). Initial soak: two clients, 110 attempts,
109 HTTP 200 and one Clients deadline failure (60 seconds), 606.063 seconds.
Five recovery reads returned 200; Clients took 33.969 seconds. The initial resource
sampler raised a ctypes argument error and missed newly spawned PG processes;
HTTP observations remain valid, resource observations are incomplete. See
performance/summary-with-sampler-limit.json. The failed sampler evidence is retained.

After correcting only the audit helper, its concurrent sampler self-test passed
(sampler-selftest.json). A fresh isolated soak completed 120/120 HTTP 200 in
624.907 seconds, two clients, 60-second deadlines. Aggregate successful p95 was
51.504 seconds. Five recovery reads returned 200; Clients took 40.665 seconds.
This confirms severe latency despite no deadline failures on the second run.

The corrected sampler recorded no errors for application or PostgreSQL trees.
Application RSS: 127,328,256 bytes initially, 137,785,344 finally, sampled peak
138,051,584; process CPU delta 7.75 seconds. PostgreSQL tree RSS: 186,818,560
initially, 341,401,600 finally, sampled peak 498,556,928; CPU delta 594.547 seconds.
Changing PostgreSQL connection processes explain part of the RSS variation;
these measurements do not establish a memory leak. Sampling at 0.2 seconds may
miss short-lived descendants. Raw windows, samples and boundaries are in
performance-soak-corrected/extended-load.json.

Cleanup is recorded in runtime.log (Redis shutdown, PostgreSQL stopped).
The application port 60177 had no listener after completion. The earlier process
session could not be polled after context restoration; completion is established
by the final JSON and shutdown logs, not an invented process exit code.
