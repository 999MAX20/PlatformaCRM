from importlib import import_module
from unittest.mock import patch

from django.db import connection, transaction
from django.db.migrations.executor import MigrationExecutor
from django.test import TransactionTestCase


CASES = {
    'billing_seed': ('billing', '0002_seed_plans'),
    'billing_limits': ('billing', '0004_update_default_entitlement_limits'),
    'widget_ids': ('bots', '0002_public_widget_ids'),
    'message_duplicates': ('bots', '0008_botmessage_unique_bot_message_external_delivery'),
    'client_identity': ('clients', '0004_client_normalized_identity'),
    'pipeline_seed': ('crm', '0002_default_pipeline'),
    'stage_canonical': ('crm', '0010_pipeline_stage_canonicalization'),
}


class InjectedMigrationFailure(Exception):
    pass


class MigrationAcceptance(TransactionTestCase):
    def exercise(self, kind):
        target = CASES[kind]
        executor = MigrationExecutor(connection)
        restore = executor.loader.graph.leaf_nodes()
        migration = executor.loader.get_migration(*target)
        previous = [d for d in migration.dependencies if d[0] == target[0]]
        try:
            executor.migrate(previous)
            executor = MigrationExecutor(connection)
            old = executor.loader.project_state(list(executor.loader.applied_migrations)).apps
            tracked = self.fixture(old, kind)
            before = self.snapshot(old, tracked)
            migration = executor.loader.get_migration(*target)
            operation = next(o for o in migration.operations if type(o).__name__ == 'RunPython')
            code = operation.code
            writes = []

            def interrupted(apps, editor):
                def intercept(execute, sql, params, many, context):
                    result = execute(sql, params, many, context)
                    if sql.lstrip().upper().startswith(('INSERT ', 'UPDATE ', 'DELETE ')):
                        writes.append(sql.split()[0])
                    return result
                with connection.execute_wrapper(intercept):
                    code(apps, editor)
                raise InjectedMigrationFailure('Synthetic interruption after data writes, before migration completion')

            with patch.object(operation, 'code', interrupted):
                with self.assertRaises(InjectedMigrationFailure):
                    executor.migrate([target])
            self.assertGreaterEqual(len(writes), 1)
            self.assertNotIn(target, MigrationExecutor(connection).loader.applied_migrations)
            self.assertEqual(before, self.snapshot(old, tracked))
            executor = MigrationExecutor(connection)
            executor.migrate([target])
            new = executor.loader.project_state([target]).apps
            self.validate(new, kind)
            after = self.snapshot(new, tracked)
            with transaction.atomic():
                code(new, None)
            self.assertEqual(after, self.snapshot(new, tracked))
            print('MIGRATION_RECEIPT', kind, 'populated-predecessor rollback-after-write retry replay PASS')
        finally:
            MigrationExecutor(connection).migrate(restore)

    def snapshot(self, apps, tracked):
        result = {}
        for label in tracked:
            model = apps.get_model(*label)
            fields = [f.attname for f in model._meta.concrete_fields if f.name != 'updated_at']
            result['.'.join(label)] = list(model.objects.order_by('pk').values(*fields))
        return result

    def fixture(self, apps, kind):
        if kind.startswith('billing'):
            Plan = apps.get_model('billing', 'SubscriptionPlan')
            Plan.objects.all().delete()
            if kind == 'billing_limits':
                Plan.objects.create(code='start', name='Custom start', monthly_price=0, limits_json={'users': 17, 'custom': 9})
            else:
                Plan.objects.create(code='custom', name='Preserved', monthly_price=1)
            return [('billing', 'SubscriptionPlan')]
        owner = apps.get_model('accounts', 'User').objects.create(username='migration-fixture', email='migration-fixture@example.test')
        business = apps.get_model('businesses', 'Business').objects.create(owner=owner, name='Synthetic migration', slug='synthetic-migration')
        if kind == 'client_identity':
            Client = apps.get_model('clients', 'Client')
            Client.objects.create(business=business, full_name='Keep A', phone='8 (777) 123-45-67', email=' Mixed@Example.Test ')
            Client.objects.create(business=business, full_name='Keep B', phone='', email='')
            return [('clients', 'Client')]
        if kind in ('widget_ids', 'message_duplicates'):
            bot = apps.get_model('bots', 'Bot').objects.create(business=business, name='Synthetic')
            channel = apps.get_model('bots', 'BotChannel').objects.create(bot=bot, channel='website')
            conv = apps.get_model('bots', 'BotConversation').objects.create(bot=bot, business=business, channel='website')
            if kind == 'widget_ids':
                return [('bots', 'BotChannel'), ('bots', 'BotConversation')]
            Message = apps.get_model('bots', 'BotMessage')
            for n in range(3):
                Message.objects.create(conversation=conv, direction='inbound', text=f'Keep {n}', external_message_id='same-id', payload_json={'keep': n})
            Message.objects.create(conversation=conv, direction='outbound', text='Other direction', external_message_id='same-id')
            return [('bots', 'BotMessage')]
        Pipeline = apps.get_model('crm', 'Pipeline')
        Stage = apps.get_model('crm', 'PipelineStage')
        if kind == 'pipeline_seed':
            return [('crm', 'Pipeline'), ('crm', 'PipelineStage')]
        pipeline = Pipeline.objects.create(business=business, name='Legacy', slug='default-sales', template_key='smb_default')
        a = Stage.objects.create(business=business, pipeline=pipeline, name='New', order=1)
        b = Stage.objects.create(business=business, pipeline=pipeline, name='Новая', order=2)
        Stage.objects.create(business=business, pipeline=pipeline, name='Custom preserved', order=3)
        client = apps.get_model('clients', 'Client').objects.create(business=business, full_name='Preserved client')
        apps.get_model('crm', 'Deal').objects.create(business=business, client=client, pipeline=pipeline, stage=b, previous_stage=b, title='Preserved deal')
        return [('crm', 'Pipeline'), ('crm', 'PipelineStage'), ('crm', 'Deal')]

    def validate(self, apps, kind):
        if kind == 'billing_seed':
            self.assertSetEqual(set(apps.get_model('billing', 'SubscriptionPlan').objects.values_list('code', flat=True)), {'custom', 'start', 'growth', 'platform'})
        elif kind == 'billing_limits':
            plan = apps.get_model('billing', 'SubscriptionPlan').objects.get(code='start')
            self.assertEqual(plan.limits_json['users'], 17)
            self.assertEqual(plan.limits_json['custom'], 9)
            self.assertEqual(plan.limits_json['bots'], 1)
            self.assertEqual(plan.name, 'Custom start')
        elif kind == 'widget_ids':
            self.assertIsNotNone(apps.get_model('bots', 'BotChannel').objects.get().public_token)
            self.assertIsNotNone(apps.get_model('bots', 'BotConversation').objects.get().public_id)
        elif kind == 'message_duplicates':
            rows = list(apps.get_model('bots', 'BotMessage').objects.filter(direction='inbound').order_by('pk'))
            self.assertEqual(len({r.external_message_id for r in rows}), 3)
            self.assertEqual(rows[0].external_message_id, 'same-id')
            self.assertEqual(rows[1].payload_json, {'keep': 1, 'legacy_external_message_id': 'same-id'})
            self.assertEqual([r.text for r in rows], ['Keep 0', 'Keep 1', 'Keep 2'])
        elif kind == 'client_identity':
            rows = list(apps.get_model('clients', 'Client').objects.order_by('pk'))
            self.assertEqual((rows[0].normalized_phone, rows[0].normalized_email), ('77771234567', 'mixed@example.test'))
            self.assertEqual((rows[1].normalized_phone, rows[1].normalized_email), ('', ''))
            self.assertEqual(rows[0].phone, '8 (777) 123-45-67')
        elif kind == 'pipeline_seed':
            self.assertEqual(apps.get_model('crm', 'Pipeline').objects.count(), 1)
            self.assertEqual(apps.get_model('crm', 'PipelineStage').objects.count(), 6)
        else:
            Stage = apps.get_model('crm', 'PipelineStage')
            target = Stage.objects.get(template_key='new')
            self.assertEqual(Stage.objects.filter(is_active=False).count(), 1)
            self.assertTrue(Stage.objects.get(name='Custom preserved').is_active)
            deal = apps.get_model('crm', 'Deal').objects.get()
            self.assertEqual((deal.stage_id, deal.previous_stage_id, deal.title), (target.pk, target.pk, 'Preserved deal'))


for name in CASES:
    def test(self, kind=name):
        self.exercise(kind)
    setattr(MigrationAcceptance, 'test_' + name, test)
