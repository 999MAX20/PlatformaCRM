# Independent review of historical native diagnostics

Only immutable revision73482a3bea7f168113c58d8cb928214c97f032d5 is in scope here.
Root read the complete new diagnostic script/result and the original deepLinks,
actionQueue, API client, app.json and App.tsx. No second runtime execution,
native build/device, external fetch or current server exposure is claimed.

The seven recorded observations include one positive custom-scheme control.
They are not seven new defects. Reconciliation with the previous register:

| Observation | Disposition |
| --- | --- |
| HTTPS task link becomes home | Confirms existing MOB-H02. app.json declares the HTTPS host/path and App passes incoming URL to the parser; parser treats hostname as section. |
| Enqueue during replay disappears | Adds a distinct reproduced scenario to MOB-H03. Replay snapshots the queue, then overwrites storage with its old remaining list. |
| Two simultaneous enqueue calls retain one | Adds a second reproduced scenario to MOB-H03. Both calls read the same list and independent writes overwrite each other. |
| Newest-first replay | Algorithm confirmed, but diagnostic uses independent completion commands; no harmful dependent-command outcome established. Record ordering risk, not another confirmed defect from this test alone. |
| Refresh503 clears session | New historical recovery defect. Every non-OK refresh invokes clearSession; App then renders LoginScreen. Temporary service unavailability causes credential removal. |
| Parallel refresh makes two calls | Confirmed lack of coalescing; backend rotation/logout consequence is not executed by this diagnostic and remains a separate scenario gap. |

Mock AsyncStorage models asynchronous read/write calls with explicit scheduling;
the replay interleaving is controlled by a promise gate. This proves the local
lost-update algorithm, not every device storage behavior. Mock fetch returns503;
it does not call an identity provider or server. Source hashes are retained in
`ui/native-function-validation.json` and match the immutable Git bodies.

Keep prior MOB-H01 actor-switch replay and MOB-H03 capacity eviction evidence.
Do not count the HTTPS case again. Future native reuse acceptance must include
actor-bound durable queue storage, capacity feedback, enqueue/replay concurrency,
unknown-outcome reconciliation, and non-destructive handling of transient refresh
errors. Session-expired/revoked behavior must remain distinct from temporary503.
Current web implementation and production authorization are separate boundaries.

## Historical server receipt recovery

Root additionally read the complete `ui/native-idempotency-validation.py` and
result, original retained idempotency implementation/model and the exact
`MobileTaskCompleteView`/`_assert_not_stale` bodies. Real in-memory Django ORM,
minimal Business/timestamp adapters and an authorized task resolver are explicitly
separate from a historical full-app execution.

Two additional historical P2 defects are supported. An expired receipt is excluded
from lookup but still owns the unique business/user/endpoint/key tuple; reuse raises
IntegrityError before executing an action. Separately, the task view checks the
old expected_updated_at before consulting a successful receipt. A first request
returns200; identical-key retry returns409 stale_state instead of replaying its
successful result. The synthetic domain adapter advances updated_at exactly once;
the proof does not execute the actual historical completion service or permissions.
The retained HomeScreen caller supplies expected_updated_at, as recorded by the UI
review. This is failed unknown-outcome recovery, not a demonstrated duplicate effect.

Acceptance before any native reuse: a successful identical request replays its
receipt despite the mutation's own version increment, while a genuinely different
request still conflicts; expired-key handling is defined and cannot cause an
uncaught uniqueness error. Concurrent same-key behavior needs PostgreSQL evidence
separately. These are historical findings, with no current API exposure claim.
