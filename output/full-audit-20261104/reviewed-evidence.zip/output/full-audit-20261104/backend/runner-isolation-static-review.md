# Static disposition: verification environment isolation

Accepted as a runner isolation/configuration defect, not evidence of an actual external call or credential disclosure.

- `scripts/codex_verify.py:62-158` SAFE_ENV does not set YCLOUD_ENABLED, YCLOUD_API_KEY, YCLOUD_WEBHOOK_SECRET or CONNECTOR_CREDENTIAL_KEYS (nor ACTIVE_KEY_ID).
- `scripts/codex_verify.py:181-212` filters inherited environment then supplies explicit safe overrides; its claim that the environment cannot inherit live settings is wider than the mechanism.
- `config/settings.py:37` unconditionally calls read_env on canonical `.env`; `:44-55` reads credential keyring and `:417-419` reads YCloud configuration.
- Installed `environ/environ.py:1051-1054,1166-1170` defaults overwrite=False and uses setdefault: keys absent from the subprocess environment can therefore be populated by the working dotenv. No dotenv secret values were inspected or emitted to establish this.
- Missing keyring configuration additionally falls through to `load_or_create_local_connector_keyring`, so absent dotenv is not sufficient for fully independent key isolation.

Mitigation for subsequent audit functional checks: use prior audit `output/comprehensive-audit-20261103/backend/manage_isolated.py` and `guard/sitecustomize.py` suppressing read_env, explicit synthetic connector keys and network guard; do not edit working settings/env.

Earlier `backend/run_probe.py` and `run_pagination_probe.py` used isolated_runtime and synthetic/disposable DBs but no read_env suppression. Their network guards and synthetic fixtures narrow effects; claim database isolation and bounded tested behavior only, not complete credential/config isolation. Results do not establish any actual external effect. Do not rerun active security probes: prior automatic review restriction remains.

Recommended product follow-up (not implemented): suppress dotenv loading in verification subprocesses by supported isolated settings/bootstrap, explicitly set synthetic keyring and provider flags, and add a sentinel-dotenv regression check in an approved isolated test. A finite denylist alone drifts when providers are added.
