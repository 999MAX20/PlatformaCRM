# Partial attachment retry

P2 confirmed by independent source-chain review and actual extracted UI mutation
execution. EntityAttachmentsPanel.tsx60–85 submits all selected files via Promise.all
and clears the selection only on complete success. One failed upload leaves the
successful file selected; another click resends both. UI attachment-retry-validation
records two calls for first.txt across two attempts, with an injected second-file
failure. Client-side selection deduplication does not track completed uploads.

Backend corroboration: FileAttachmentViewSet.perform_create50–71 calls save for
each POST; FileAttachmentSerializer.create380–386 uses ModelSerializer.create;
attachment_upload_path21–24 gives each save a fresh UUID path. FileAttachment170–210
has no request/content uniqueness constraint. Consequently retrying a successful
file creates another attachment/blob rather than replaying the prior result.

Root read frontend component1–160, backend view1–110, serializer365–393 and model
1–32/169–216. Backend reviewer independently corroborated the same chain. No real
upload, external delivery, security-bypass test or end-to-end persistence reproduction
was performed for this finding. The extracted function uses explicit API adapters.

Acceptance: retain per-file success, retry only failed files, refresh visible partial
results, and prove partial-success retry does not duplicate attachments. Server
idempotency may further protect lost responses but is not claimed as implemented.
