import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
load = lambda name: json.loads((OUT / name).read_text(encoding='utf-8'))
journal = load('file-journal.json')
history = load('historical-file-receipts.json')
assignment = json.loads((OUT.parent / 'backend-assignment-refined.json').read_text(encoding='utf-8'))
receipts = {row['path']: row for row in journal if row.get('kind') == 'text'}
receipts.update({row['path']: row for row in history})
errors = []
for row in assignment:
    path = row['path']
    receipt = receipts.get(path)
    if not receipt:
        errors.append({'path': path, 'error': 'missing receipt'})
        continue
    digest = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
    if digest != row['sha256'] or digest != receipt['sha256']:
        errors.append({'path': path, 'error': 'source hash changed'})
    count = receipt['line_count']
    cursor = 1
    for start, end in sorted(receipt.get('read_ranges', [])):
        if start > cursor:
            break
        cursor = max(cursor, end + 1)
    if cursor <= count:
        errors.append({'path': path, 'error': 'incomplete read ranges', 'first_gap': cursor})
    if not receipt.get('purpose') or not receipt.get('review_depth'):
        errors.append({'path': path, 'error': 'missing semantic receipt'})
result = {'assignment_paths': len(assignment), 'receipt_paths': len(receipts),
    'current_text_files': sum(row.get('kind') == 'text' for row in journal),
    'current_text_lines': sum(row['line_count'] for row in journal if row.get('kind') == 'text'),
    'historical_paths': len(history), 'errors': errors,
    'boundary': 'Verifies recorded full-read coverage, semantic receipt presence and exact snapshot bytes. Does not convert static review into runtime/branch acceptance.'}
(OUT / 'coverage-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(bool(errors))
