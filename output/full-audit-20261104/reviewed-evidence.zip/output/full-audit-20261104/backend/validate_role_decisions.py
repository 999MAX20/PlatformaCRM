import hashlib
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
load=lambda name:json.loads((OUT/(name+'.json')).read_text(encoding='utf-8'))
contract=load('role-decision-contract')
rows=load('role-action-scope-matrix')
tests={t['test_id']:t for t in load('test-assertion-matrix')}
sources={s['id']:s for s in contract['source_functions']}
receipts={t['test_id']:t for t in contract['named_existing_test_receipts']}
errors=[]
for source in sources.values():
    path=ROOT/source['path']
    text=path.read_text(encoding='utf-8-sig')
    if hashlib.sha256(path.read_bytes()).hexdigest()!=source['sha256'] or '\n'.join(text.splitlines()[source['line']-1:source['end_line']])!=source['source']:
        errors.append(source['id'])
for key,receipt in receipts.items():
    actual=tests[key]
    if receipt['execution']!=actual['execution'] or receipt['assertions']!=actual['assertions']:
        errors.append(key)
for row in rows:
    if row['effective_boolean'] is not None or row['decision_contract_id']!=contract['id']:
        errors.append(row['id'])
    if set(row['decision_source_ids'])-sources.keys() or set(row['related_named_test_ids'])-receipts.keys():
        errors.append(row['id'])
owner=next(r for r in rows if r['id']=='role:owner/payments/view')
assert owner['preset_allowed'] and owner['preset_scope']=='business'
summary={'rows':len(rows),'source_functions':len(sources),'test_receipts':len(receipts),'errors':errors,'boundary':contract['boundary']}
(OUT/'role-decision-validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
raise SystemExit(bool(errors))
