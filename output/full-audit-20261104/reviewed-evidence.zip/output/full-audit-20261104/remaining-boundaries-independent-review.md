# Independent review of the final ordinary backend boundaries

Root read the complete seven-case probe and structured observations, original
failure/recheck log endings, and the source paths below. No second root execution,
provider call, real credential use or working-data mutation is claimed.

| Case | Independent disposition |
| --- | --- |
| Deal required payload | Confirmed P2. apply_deal_stage validates expected_close_at from payload, moves stage, but its update_fields do not persist that value. Missing-field control rejects and preserves stage; supplied value permits move while DB field remainsNULL. HTTP move-stage passes request.data to this service, so this is not an isolated unused-helper assumption. |
| Deal requestless audit | Observation is valid, but not promoted to current production audit-loss defect. HTTP callers supply request; the AI executor constructs request_context and forwards it through transitions. Only direct optional-service calls in tests were found requestless. Activity/history remain present. Keep as service hardening boundary. |
| Zero service price | Confirmed P2 context-data loss: Decimal0 and None both become an empty string, while10 remains10. Current no-branch scheduling context uses this helper for services and matched_service. No generated false answer or charged amount was demonstrated. |
| Lead-created appointment responsible | Confirms another caller scenario of prior REQ03: direct helper and lead contract wrapper create the booking but leave Appointment.responsible_user NULL. Lead responsible remains and is supplied to followups; do not claim every notification is lost. |
| Public clients cap | Confirmed P2 integration functionality gap:105 owned clients, first and page2/offset responses contain identical100 IDs. The real get implementation slices100 and reads no pagination input. Authorized-token return was mocked; authentication/tenant bypass was not tested or claimed. |
| Attachment rename audit failure | Confirmed P2 atomicity/recovery gap: positive rename200, injected audit failure500, new name still persisted without new audit. Only metadata changed; storage was never opened. View saves before audit without a surrounding transaction. |
| Connector config audit failure | Confirmed P2 atomicity gap: synthetic encrypted credential/config remains saved and status connected after audit exception, with no new audit. Service and current config-action caller have no encompassing atomic transaction. No provider validation/delivery or real credential readback. |

Reviewed source: crm/services.py185–344 and449–490, crm/views.py253–265;
scheduling/services.py76–138 and leads/services.py440–483;
bots/scheduling_context.py1–51,153–159;
integrations/views.py521–533, integrations/services.py158–201 and
view_actions.py29–44; file_attachment_views.py89–111. Requestless applicability
trace is independently supplied in backend's final candidate disposition and
crm_tools.request_context/execute_crm_mutation → crm_transitions source chain.

The original seven-test batch reports6 PASS and1 failed harness expectation:
the global exception handler returns500 instead of propagating RuntimeError to
assertRaises. Only that expectation was corrected to observe500; the persisted
name/no-audit assertions remain. Focused repeat1 PASS is defect evidence, not
healthy acceptance. Exact log SHA/lines: backend/remaining-boundary-findings.json.

Future acceptance: required field validation must reflect persisted state after
the atomic transition; zero stays distinguishable from unknown; all supported
client pages have deterministic continuation; appointment creation paths share
the approved responsibility invariant; failed audit cannot silently leave a
sensitive mutation committed. For file storage, DB rollback alone is insufficient
to claim blob cleanup—this diagnostic covers rename metadata only. Preserve
current source permissions, tenant checks and idempotent recovery during fixes.

## Additional lead-contract creation-effect control

Root subsequently read complete probe_booking_automation.py, its result and final
log. This invokes the real locked lead-contract wrapper with a valid active
appointment_created→create_task rule under inline automation. A new appointment
exists, but no matching AutomationRun or preparation task; calling the existing
handle_appointment_created for that appointment then creates both successfully.
This isolates a missing invocation from an invalid rule or unavailable worker.
It extends prior CRM-EVENT01 and REQ03, rather than adding duplicate findings.
No notification provider delivery was executed, and inline execution does not
certify a real broker/worker topology. Receipt: backend/booking-automation-results.json.

## Invalid task version input

Root read complete probe_task_version.py, task-version-results.json/final log and
tasks/mutations.py1–66. An owner starts a synthetic Task with impossible calendar
value2026-02-31 in X-Task-Version: parse_datetime raises and API returns500 while
state/version remain unchanged. Valid stale control returns409; current version
returns200 and in_progress. This is a P2 invalid-input error classification defect,
not lost data, a concurrency proof or an authorization experiment. The earlier
static-only label has now been replaced by this actual focused observation.
Acceptance: invalid syntax/calendar values yield a stable4xx with no mutation;
stale valid versions retain conflict behavior, current versions still transition.
