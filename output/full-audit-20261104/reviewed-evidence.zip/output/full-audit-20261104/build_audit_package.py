"""Package an explicit reviewed allowlist; omitted raw evidence stays local."""
import hashlib, json, zipfile
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
proposal=json.loads((OUT/'backend/safe-packaging-proposal.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
archive=OUT/'reviewed-evidence.zip'
included=[];direct=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in proposal['selected']:
  name=row['path'];p=(ROOT/name).resolve()
  assert p.is_relative_to(OUT.resolve()) and p.is_file() and not p.is_symlink()
  data=p.read_bytes()
  assert len(data)==row['size'] and sha(data)==row['sha256'],f'Reviewed input changed: {name}'
  is_direct=(p.parent==OUT/'report' and p.suffix in {'.md','.json'}) or p.name=='restore_audit_package.py'
  r={'path':name,'size':len(data),'sha256':sha(data),'storage':'direct' if is_direct else 'archive'}
  included.append(r)
  if is_direct:direct.append(name)
  else:
   info=zipfile.ZipInfo(name,date_time=(2026,11,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
assert (OUT/'restore_audit_package.py').relative_to(ROOT).as_posix() in direct
assert len(included)==len({r['path'] for r in included})
manifest={'status':'REVIEWED_LOCAL_ARTIFACT_PACKAGE','audited_head':'d27044b1f923fff6a4a02d4834b4731dc8eabce5','boundary':'Own audit artifacts only; original product/WIP bytes are not staged. This package is not self-contained runtime evidence and authorizes no publication. Direct text is a convenience copy; exact named input hashes are retained. Omitted raw artifacts remain in local audit output.','archive':{'filename':archive.name,'size':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':sum(r['storage']=='archive' for r in included)},'included_count':len(included),'included_bytes':sum(r['size'] for r in included),'included':included,'omitted_count':proposal['omitted_count'],'omitted_bytes':proposal['omitted_bytes'],'omitted':proposal['omitted'],'review_limits':proposal['review_limits'],'scan_findings':proposal['scan_findings'],'self_boundary':'Manifest and archive are excluded from their own member census to avoid recursive self-hashing; later local-save.json records commit outcome separately.'}
(OUT/'package-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
stage=direct+[str(archive.relative_to(ROOT)).replace('\\','/'),'output/full-audit-20261104/package-manifest.json']
(OUT/'package-stage-paths.json').write_text(json.dumps(stage,indent=2),encoding='utf-8')
print(json.dumps({'included':len(included),'archive_entries':manifest['archive']['entries'],'uncompressed_bytes':manifest['included_bytes'],'archive_bytes':manifest['archive']['size'],'direct_files':len(direct),'omitted':manifest['omitted_count']}))
