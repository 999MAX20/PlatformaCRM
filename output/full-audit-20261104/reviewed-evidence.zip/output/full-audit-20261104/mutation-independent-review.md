# Independent review: ordinary mutations

Root reviewed the complete synthetic probe, source paths and actual log results on
the current d27044b1 + preserved WIP snapshot. No product edit or new execution.

| Finding | Independent assessment | Boundary |
| --- | --- | --- |
| MANUAL-SALE-NONFINITE | P2 confirmed: parse_decimal accepts Decimal NaN, normalize_sale_payload serializes it; quantity zero falls through `or Decimal("1")`. POST returns201 and BusinessEvent holds NaN/1. | Data event corruption only; no Payment ledger, financial dashboard or actual sale demonstrated. |
| CATALOG-FRACTIONAL-DURATION | P2 confirmed: int(Decimal("1.9")) truncates to1 despite positive-integer validation wording; actual Service persisted with duration1. | Manual catalog endpoint; no appointment consequence executed. |
| CATALOG-INFINITY-500 | P2 input rejection defect confirmed: int(Decimal("Infinity")) raises uncaught OverflowError, endpoint500. | Probe establishes no service/event created; not data corruption. |
| PIPELINE-TEMPLATE-PARTIAL | P2 confirmed: apply_template creates pipeline then stages without an atomic boundary. Injected failure on second child leaves pipeline+first stage after500. | Real ORM except injected second create failure; not a production incident claim. |
| LEAD-FORM-TEMPLATE-PARTIAL | P2 confirmed: create_template similarly persists form+first field before second create fails. | First batch400 was invalid fixture (missing owner membership). Corrected one-test result proves500/partial rows; preserve both logs. |
| IDEMPOTENCY-PRUNE-RECLAIM | P2 confirmed: prune snapshots expired IDs, then deletes by ID only; begin_crm_command legitimately renews same row before deletion. | Deterministic real-ORM interleaving, not simultaneous PostgreSQL processes or proof of duplicate real action. |

Source reviewed: apps/core/import_export.py755–897; import_export_views.py150–215;
apps/crm/views.py1–90; apps/leads/views.py462–512; apps/core/idempotency.py88–193
and final70 lines. No ATOMIC_REQUESTS declaration found under config. The framework
probe confirms partial persistence inside its enclosing test transaction.

Evidence: backend/functional-mutation-findings.json contains source SHA256, precise
test method hashes and log lines. Root consumed full probe_functional_mutations.py,
functional-mutation-observations.log final15 and form-recheck final12 lines. Initial
batch5 PASS/1 fixture FAIL and corrected form1 PASS are distinct receipts. Observation
PASS means reproducing a defect; it is not product acceptance.

Remediation acceptance: reject nonfinite/fractional numeric values, preserve explicit
zero semantics; wrap template parent+children in one transaction and prove rollback;
make expiry deletion conditional on still-expired state and prove reclaim survives.
Any proposed policy for valid zero sales quantity must be reconciled with the owner
contract; silently converting supplied zero to one is the observed current behavior.
