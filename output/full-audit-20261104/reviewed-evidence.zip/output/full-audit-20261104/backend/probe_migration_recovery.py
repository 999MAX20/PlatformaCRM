from types import SimpleNamespace
from unittest.mock import patch

from django.db import connection, transaction
from django.db.migrations.executor import MigrationExecutor
from django.test import TransactionTestCase
from django.utils import timezone


class InterruptedDataMigration(Exception):
    pass


class OrdinaryMigrationRecovery(TransactionTestCase):
    def exercise(self, app, name):
        target = (app, name)
        executor = MigrationExecutor(connection)
        restore = executor.loader.graph.leaf_nodes()
        migration = executor.loader.get_migration(*target)
        before_target = [d for d in migration.dependencies if d[0] == app]
        try:
            executor.migrate(before_target)
            executor = MigrationExecutor(connection)
            old = executor.loader.project_state(list(executor.loader.applied_migrations)).apps
            tracked = self.fixture(old, app)
            before = self.snapshot(old, tracked)
            migration = executor.loader.get_migration(*target)
            operation = next(o for o in migration.operations if type(o).__name__ == 'RunPython')
            code = operation.code
            writes = []

            def fail_after_writes(apps, editor):
                def record(execute, sql, params, many, context):
                    result = execute(sql, params, many, context)
                    if sql.lstrip().upper().startswith(('INSERT ', 'UPDATE ', 'DELETE ')):
                        writes.append(sql.split()[0])
                    return result
                with connection.execute_wrapper(record):
                    code(apps, editor)
                raise InterruptedDataMigration('Synthetic failure after data writes before migration completion')

            with patch.object(operation, 'code', fail_after_writes):
                with self.assertRaises(InterruptedDataMigration):
                    executor.migrate([target])
            self.assertTrue(writes)
            self.assertNotIn(target, MigrationExecutor(connection).loader.applied_migrations)
            self.assertEqual(before, self.snapshot(old, tracked))
            executor = MigrationExecutor(connection)
            executor.migrate([target])
            new = executor.loader.project_state([target]).apps
            self.validate(new, app)
            after = self.snapshot(new, tracked)
            with transaction.atomic():
                code(new, SimpleNamespace(connection=connection))
            self.assertEqual(after, self.snapshot(new, tracked))
            print('MIGRATION_RECOVERY_RECEIPT', app, name, 'populated rollback retry replay PASS')
        finally:
            MigrationExecutor(connection).migrate(restore)

    def snapshot(self, apps, tracked):
        return {'.'.join(label): list(apps.get_model(*label).objects.order_by('pk').values()) for label in tracked}

    def fixture(self, apps, app):
        owner = apps.get_model('accounts', 'User').objects.create(username='recovery-fixture', email='recovery-fixture@example.test')
        business = apps.get_model('businesses', 'Business').objects.create(owner=owner, name='Synthetic recovery', slug='synthetic-recovery')
        if app == 'ai_core':
            bot = apps.get_model('bots', 'Bot').objects.create(business=business, name='Preserved', settings_json={'scenario': 'inbox'})
            Knowledge = apps.get_model('ai_core', 'BusinessKnowledgeItem')
            for n in range(2):
                Knowledge.objects.create(business=business, bot=bot, title=f'Keep {n}', content=f'Synthetic preserved {n}')
            return [('ai_core', 'BusinessKnowledgeItem')]
        Notification = apps.get_model('notifications', 'Notification')
        now = timezone.now()
        for n in range(2):
            Notification.objects.create(business=business, recipient=owner, text=f'Keep {n}', channel='system', send_at=now,
                                        status='sent', delivered_at=now, read_at=now)
        return [('notifications', 'Notification'), ('notifications', 'NotificationRecipient')]

    def validate(self, apps, app):
        if app == 'ai_core':
            rows = list(apps.get_model('ai_core', 'BusinessKnowledgeItem').objects.order_by('pk'))
            self.assertEqual([r.content for r in rows], ['Synthetic preserved 0', 'Synthetic preserved 1'])
            self.assertEqual([r.customer_visible for r in rows], [True, True])
            return
        notifications = list(apps.get_model('notifications', 'Notification').objects.order_by('pk'))
        Recipient = apps.get_model('notifications', 'NotificationRecipient')
        self.assertEqual(Recipient.objects.count(), 2)
        for item in notifications:
            state = Recipient.objects.get(notification_id=item.pk, user_id=item.recipient_id)
            self.assertEqual(state.read_at, item.read_at)
            self.assertEqual(state.received_at, item.created_at)
            self.assertIsNone(state.opened_at)
            self.assertIsNone(state.acknowledged_at)
            self.assertIsNotNone(item.audience_fixed_at)
            self.assertEqual(item.status, 'sent')
            self.assertEqual(item.attempts, 0)
            self.assertIsNotNone(item.delivered_at)

    def test_ai_knowledge_data_recovery(self):
        self.exercise('ai_core', '0008_customer_knowledge_visibility')

    def test_notification_recipient_data_recovery(self):
        self.exercise('notifications', '0007_backfill_personal_recipients')
