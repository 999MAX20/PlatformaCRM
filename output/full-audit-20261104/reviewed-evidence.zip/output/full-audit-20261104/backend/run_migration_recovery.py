import base64
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT))
from scripts.codex_verify import isolated_runtime

prior = ROOT / 'output/comprehensive-audit-20261103/backend'
labels = sys.argv[1:] or ['probe_migration_recovery']
log_path = OUT / ('functional-edge-recheck.log' if sys.argv[1:] else 'functional-edge-observations.log')
if labels[0].startswith('probe_functional_mutations'):
    log_path = OUT / 'functional-mutation-observations.log'
    if '.test_lead_form_' in labels[0]:
        log_path = OUT / 'functional-mutation-form-recheck.log'
if labels[0].startswith('probe_remaining_functional'):
    log_path = OUT / ('remaining-functional-recheck.log' if '.' in labels[0] else 'remaining-functional-observations.log')
if labels[0].startswith('probe_state_edges'):
    log_path = OUT / ('state-edge-recheck.log' if '.' in labels[0] else 'state-edge-observations.log')
if labels[0].startswith('probe_final_functional'):
    log_path = OUT / ('final-functional-recheck.log' if '.' in labels[0] else 'final-functional-observations.log')
if labels[0].startswith('probe_alert_transition'):
    log_path = OUT / 'alert-transition.log'
if labels[0].startswith('probe_performance_helpers'):
    log_path = OUT / ('helper-performance-recheck.log' if '.' in labels[0] else 'helper-performance.log')
if labels[0].startswith('probe_adapter_boundaries'):
    log_path = OUT / 'adapter-boundaries.log'
if labels[0].startswith('probe_remaining_boundaries'):
    log_path = OUT / ('remaining-boundaries-recheck.log' if '.' in labels[0] else 'remaining-boundaries.log')
if labels[0].startswith('probe_booking_automation'):
    log_path = OUT / 'booking-automation.log'
if labels[0].startswith('probe_task_version'):
    log_path = OUT / 'task-version.log'
log_path = OUT / 'migration-recovery.log'
with isolated_runtime(python=sys.executable) as runtime:
    env = runtime.environment.copy()
    env.update(PYTHONPATH=os.pathsep.join([str(prior/'guard'),str(OUT),str(ROOT)]), PYTHONDONTWRITEBYTECODE='1',
        CONNECTOR_CREDENTIAL_KEYS=json.dumps({'audit-synthetic':base64.urlsafe_b64encode(b'A'*32).decode()}),
        CONNECTOR_CREDENTIAL_ACTIVE_KEY_ID='audit-synthetic', YCLOUD_ENABLED='False',YCLOUD_API_KEY='',YCLOUD_WEBHOOK_SECRET='')
    with log_path.open('w', encoding='utf-8') as log:
        result = subprocess.run([sys.executable,'-B',str(prior/'manage_isolated.py'),'test',*labels,'--noinput','-v','2'], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    print('EXIT', result.returncode, 'LOG', str(log_path))
    raise SystemExit(result.returncode)


