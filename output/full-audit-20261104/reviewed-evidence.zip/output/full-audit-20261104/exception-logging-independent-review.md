# Conditional secret logging — root independent static review

P2 operational confidentiality defect, conditional on a secret-bearing exception.
No real leaked credential or external exploitation is established.

apps/integrations/kaspi/base.py catches provider failures and calls logger.exception
at validation/sync boundaries, while returning a generic public reason and
sanitizing persisted run.error. apps/integrations/tests_connectors.py164–185
explicitly injects a synthetic access_token-bearing RuntimeError and asserts
the raw marker appears in captured logs. That assertion alone would not prove
the deployed handler output, because assertLogs installs its own handler.

Independent root review checked the actual configured path: config/settings.py
581–608 supplies a StreamHandler with JsonLogFormatter and RequestContextFilter.
The filter adds request/release/environment context only. apps/core/logging.py
passes record.getMessage() and formatException(record.exc_info) to JSON without
redaction. Thus the configured console also preserves the exception value.
apps/core/exceptions.py similarly records raw exc_info for unhandled exceptions;
public response sanitization is a separate boundary. Optional Sentry captures the
exception too, but external Sentry processing/configuration was not tested.

This differs from the paid-beta raw broker URL finding: exception logging needs
an exception containing sensitive material; the readiness command copies its
configuration directly. Group the common redaction policy remediation, preserve
both reproduction paths. No provider request or active security probe was run.

Acceptance: synthetic secrets in exception messages/chains, log arguments and
supported context fields must be absent from the configured console output while
retaining useful error type/stack/request correlation. Preserve generic API and
sanitized persisted error behavior. Inspect configured error-reporting sinks
separately before claiming those sinks safe. The existing raw-token assertion
must be changed to the intended confidentiality invariant, not simply removed.
