"""Bounded identity allowance for two reviewed documentation corrections."""
import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
def matched(path,baseline,current):
    final_receipt=OUT/'final-doc-integration/receipt.json'
    if final_receipt.exists():
        for row in json.loads(final_receipt.read_text(encoding='utf-8')):
            if row['path'] != path: continue
            before=(OUT/row['baseline_snapshot']).read_bytes()
            after=(ROOT/path).read_bytes()
            baseline_matches=row['before_sha256']==baseline
            if row['kind']=='exact-preserved-baseline-body-with-own-prefix' and not baseline_matches:
                initial=json.loads((OUT/'source-baseline.json').read_text(encoding='utf-8'))
                initial_hash=next((r['sha256'] for r in initial['files'] if r['path']==path),None)
                prefixes=json.loads((OUT/'requirements/current-prefix-reconciliation.json').read_text(encoding='utf-8'))
                prefix=next((r for r in prefixes if r['path']==path),{})
                earlier=json.loads((OUT/'source-drift-07.json').read_text(encoding='utf-8'))
                checked=next((r for r in earlier['changes'] if r['path']==path),None)
                chain=(prefix.get('current_sha256')==baseline or
                       (checked and checked['baseline_sha256']==baseline and checked['current_sha256']==prefix.get('current_sha256') and checked['status']=='exact-original-body-with-own-prefix'))
                baseline_matches=(initial_hash==baseline and prefix.get('original_sha256')==row['before_sha256'] and earlier['status']=='PASS' and bool(chain))
            if not (hashlib.sha256(before).hexdigest()==row['before_sha256'] and baseline_matches
                    and hashlib.sha256(after).hexdigest()==row['after_sha256']==current):
                return False
            if row['kind']=='exact-preserved-baseline-body-with-own-prefix':
                return after==row['own_prefix'].encode('utf-8')+before
            if row['kind']=='additive-audit-evidence-registration':
                return after.decode('utf-8')==before.decode('utf-8').replace('  "documents": [\n','  "documents": [\n'+row['insert'],1)
            return False
    receipt=OUT/'doc-integration/receipt.json'
    if not receipt.exists(): return False
    for row in json.loads(receipt.read_text(encoding='utf-8')):
        if row['path']!=path: continue
        before=(OUT/'doc-integration'/ (Path(path).name+'.before')).read_bytes()
        after=(ROOT/path).read_bytes()
        return (hashlib.sha256(before).hexdigest()==row['before_sha256']==baseline
                and hashlib.sha256(after).hexdigest()==row['after_sha256']==current)
    return False
