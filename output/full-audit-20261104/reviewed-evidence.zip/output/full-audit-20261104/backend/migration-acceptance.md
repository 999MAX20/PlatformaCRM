# Migration acceptance boundary

This is audit evidence, not authorization to migrate a working database or a supported-release declaration. Product/configuration sources are unchanged.

Result: nine new populated predecessor/failure/retry/replay scenarios PASS (six in `migration-acceptance.log`, the corrected stage fixture in `migration-stage-recheck.log`, and two ordinary data-recovery cases in `migration-recovery.log`, exit 0). All 14 acceptance rows match their migration-source hashes; existing test source hashes also match. This closes the nine named synthetic scenarios, not every migration/deployment boundary below.

## From zero and previous state

The registry contains 152 migration modules, including 12 `RunPython` data migrations and no `RunSQL` operations. The prior full backend run successfully built a fresh isolated database before its separately recorded application-test failures. The new `migration-acceptance.log` likewise records fresh SQLite test-database creation and migration application. Existing migration-drift evidence remains separate: no new migration or schema change was made here.

No explicit list of supported previous deployment releases was identified in `docs/current/operations.md` or `docs/testing/testing.md`. Operations requires an agreed backup/rollback plan and prohibits destructive schema rollback without it; the testing guide requires applicable compatibility/data-migration proof. Immediate graph predecessors below are concrete test states, **not** a claim that every historical release or arbitrary customer database is supported. A previous release, database engine/version, representative data and deployment target must be identified before claiming release-upgrade acceptance.

## Populated migration scenarios

`migration-acceptance-rows.json` lists every data migration and the two additional existing additive-schema upgrade fixtures, their source hashes, graph dependencies, exact test receipts and gaps. `migration-acceptance-summary.json` gives machine-readable totals and receipt hashes.

New ordinary synthetic scenarios use the real `MigrationExecutor`, historical model states and isolated SQLite database:

| Migration | Populated data assertion |
| --- | --- |
| billing0001 → 0002 | Seed standard plans; preserve an unrelated custom plan; repeated seed does not duplicate rows. |
| billing0003 → 0004 | Add missing default limits while preserving an explicit user limit and custom key/name. |
| bots0001 → 0002 | Populate non-null channel/conversation public identifiers; repeated function preserves them. No authentication or public-token attack probe. |
| bots0007 → 0008 | Preserve duplicate message bodies/payload, retain original external ID metadata, make duplicate IDs distinct without conflating directions. |
| clients0003 → 0004 | Normalize legacy phone/email, retain source values, handle empty values. |
| crm0001 → 0002 | Create one default pipeline and six stages for an existing business; repeat without duplicates. |
| crm0009 → 0010 | Canonicalize aliased stages, repoint both current/previous Deal stage, retain Deal content and custom stage, deactivate duplicate. |
| ai_core0007 → 0008 | Preserve two existing owned Inbox knowledge rows and populate their visibility; rollback data/schema on interruption, retry and replay. This is a data transformation check, without API access, actor switch or authorization probing. |
| notifications0006 → 0007 | Preserve two personal sent/read notifications, backfill corresponding read-state rows without changing delivery metadata; rollback both rows/marker on interruption, retry and replay without duplicates. No role/identity probing. |

Each new case interrupts after real `RunPython` data writes return but before migration completion. It checks original rows restored and migration not recorded, then retries the actual migration and repeats the data function to check stable results. This proves a bounded transactional failure point; it does not prove every per-row interruption, abrupt process kill, PostgreSQL DDL/locks, production-sized input or reverse-migration data recovery. The script restores the complete current graph before the next test.

The initial attempt injected an exception inside SQL execution during `model.save`. SQLite schema-editor constraint checking then encountered Django's broken transaction state; subsequent cases were contaminated. That attempt remains in `migration-acceptance-initial-harness-failure.log`. It is not a product PASS or a proven production defect. The corrected injection is outside ORM write calls and retains the stated failure-point limit. The corrected suite had six PASS and one fixture error: the stage test omitted required `Deal.client_id` before executing the target migration. After supplying that fixture relation, the focused stage test passed with exit 0; the six unaffected cases were not repeated. The original probe snapshot and both logs are retained. Exact final outcomes are in the summary and logs.

## Existing evidence and remaining gaps

- **ai_core0007 → 0008**, with bots0011 dependency: existing `CustomerSafetyMigrationTests` proves owned Inbox/legacy knowledge audience, shared material privacy and conversation/message preservation. The new ordinary recovery test additionally proves after-write rollback/retry/replay for two owned Inbox rows. Existing authorization-related audience evidence is reused; no new security probe.
- **notifications0005 → 0007**: existing `PersonalNotificationMigrationTests` proves audience/read-state preservation, no resend and repeat backfill not retroactively subscribing new members. The new ordinary recovery test additionally proves populated 0006 → 0007 after-write rollback/retry/replay for personal sent/read notifications.
- **integrations0006**: existing encrypted-config test invokes the migration function on current models and verifies credential extraction/preservation. It is not a populated historical-executor upgrade or partial-encryption/missing-key failure test. No new protected security probe.
- **businesses0002** role seeding and **businesses0008** capability backfill: fresh empty-database execution and source review exist; populated historical migration, interrupted writes and repeat behavior have no specific behavioral receipt in the reviewed test inventory. General current permission tests do not close this migration-specific gap. No new protected security probe.
- **scheduling0009 → 0010**: existing `RecordMigrationTests` preserves completed record history/timestamps and nullable relationships while adding responsible/source fields.
- **tasks0010 → 0011**: existing `TaskWorkspaceMigrationTests` preserves status, assignment, watcher and comment history with new default fields.

Reverse functions include irreversible/no-op data transformations and deletes of seeded records; test teardown is not a safe customer rollback policy. The named supported prior release, production database upgrade, PostgreSQL migration-failure behavior and the specific uncovered populated security migrations remain explicit acceptance boundaries.

## Commands and environment

`.\.venv\Scripts\python.exe -B output/full-audit-20261104/backend/run_migration_acceptance.py` uses the repository's `isolated_runtime`, existing dotenv suppression/network guard, synthetic credential key and in-memory Django test database. Focused repeat adds `probe_migration_acceptance.MigrationAcceptance.test_stage_canonical`. No working database, provider, real credential, product/configuration file or deployment was changed. The first, corrected and focused runs are retained separately. The evidence generator is `record_migration_acceptance.py`; its output is a receipt summary, not another application test.

`.\.venv\Scripts\python.exe -B output/full-audit-20261104/backend/run_migration_recovery.py` runs the two ordinary AI/notification recovery cases with the same isolation; 2 PASS, exit 0. Role/capability and credential migrations received no new populated behavioral scenario. The remaining three data-migration failure gaps are businesses0002, businesses0008 and integrations0006.

## Queue count reconciliation

The static source has 13 possible scheduled tasks. The isolated default runtime has 12 enabled beat entries. The extra `kaspi-pricing-cycle` is conditional on `KASPI_REPRICING_SCHEDULE_ENABLED=True`, whose default is False (`config/settings.py:408,483–487`). `queue-schedule-reconciliation.json` and the corrected business-process description preserve both boundaries. Neither count proves a live consumer or active deployed scheduler.
