# Inbox pagination: independent root review

Confirmed functional defect, P2: following the returned message cursor omits one
saved message at each full page boundary. Data remains stored; this is omission
from paginated history, not deletion.

Current implementation: apps/conversations/inbox_helpers.py lines 219–250 selects
limit+1 messages, uses message_window[limit].id as next_before_id, then truncates
to limit. The next call applies id__lt=before_id, excluding that lookahead row.
inbox_views.py lines 181–194 calls this helper. Current frontend
features/conversations/useInboxQueries.ts lines 134–149 follows next_before_id
with limit 200; ConversationsPage exposes Load More through ConversationThreadPane.
The static cause and frontend reachability were independently read by root and
the UI reviewer before the backend execution.

Backend audit test backend/probe_pagination.py creates five synthetic messages in
an isolated Django TestCase. A limit=10 control returns all five and limit=0
returns 400. Following limit=2 cursors returns [4,5] with next_before_id=3,
then [1,2] with has_more=false. Message 3 is absent. The invariant assertion fails
as intended, exit 1, rather than redefining the failure as product PASS.

Root independently read the complete probe, isolation runner and bounded result
log. Fixture has one owner, Business, bot and conversation, all messages inbound;
network connect is denied during requests. No mocking replaces the pagination
helper or API result. Test database teardown is present in pagination-probe.log.
This review is independent static/evidence validation, not a second execution.

Remediation acceptance: return a cursor consistent with the strict comparison
(normally the oldest returned ID), and cover exact limit, limit+1, multiple
pages, sparse IDs and concurrent newly appended messages without omission or
duplication. Check the reachable Load More flow at its actual page size. No fix
is made by this audit.
