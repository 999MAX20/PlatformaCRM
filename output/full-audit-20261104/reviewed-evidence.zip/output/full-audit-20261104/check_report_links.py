"""Check local Markdown destinations in the evolving report package."""
import json
import re
from pathlib import Path
from urllib.parse import unquote

OUT = Path(__file__).resolve().parent
report = OUT / "report"
checked = []
errors = []
for path in sorted(report.glob("*.md")):
    for match in re.finditer(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        target = match.group(1).strip().strip("<>")
        if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", target) or target.startswith("#"):
            continue
        destination = unquote(target.split("#", 1)[0])
        actual = (path.parent / destination).resolve()
        row = {"document": path.name, "target": target, "exists": actual.exists()}
        checked.append(row)
        if not row["exists"]:
            errors.append(row)
result = {"status": "PASS" if not errors else "FAIL", "documents": len(list(report.glob("*.md"))),
          "links": len(checked), "errors": errors,
          "boundary": "Destination existence only; document claims and coverage require separate evidence review."}
(OUT / "report-link-check.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(result, ensure_ascii=False))
