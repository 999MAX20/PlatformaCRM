"""Cross-registry structural checks; runtime limits remain separate from PASS."""
import csv,hashlib,json,collections,argparse
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
def read(name):return json.loads((OUT/name).read_text(encoding='utf-8-sig'))
def csvrows(name):
 with (OUT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
errors=[]
def check(ok,kind,detail=None):
 if not ok:errors.append({'kind':kind,'detail':detail})
def filehash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks={
'global-review-validation-final.json':('status','STRUCTURAL_IDENTITY_PASS'),
'root-read-validation.json':('status','PASS'),
'ui/coverage-validation.json':('status','PASS'),
'ui/routes-ui-export-validation.json':('status','PASS'),
'requirements/document-coverage-validation.json':('status','PASS'),
'requirements/requirements-validation.json':('status','PASS'),
'backend/coverage-validation.json':('errors',[]),
'backend/final-artifact-validation.json':('errors',[]),
'backend/semantic-transition-validation.json':('errors',[]),
'remediation-mapping-validation.json':('status','PASS'),
'report-link-check.json':('status','PASS')}
for name,(key,value) in checks.items():
 d=read(name);check(d.get(key)==value,'component-validator',{'path':name,'key':key,'actual':d.get(key)})
census=csvrows('file-inventory-refined.csv');review=csvrows('file-review.csv');cp=[r['path'] for r in census];rp=[r['path'] for r in review]
check(len(cp)==len(set(cp))==127843,'census-denominator');check(set(cp)==set(rp) and len(rp)==len(cp),'review-join')
own=[r for r in census if r['required_depth'] in {'full-text','encoding-review'}];check(len(own)==5734,'own-text-denominator')
merged=read('ui/action-state-reconciled.json');sites=merged['rows'];check(len(sites)==3014,'ui-site-denominator');check(not merged.get('issues') and not merged.get('missing_references'),'ui-reference-errors')
instances=[r.get('instance_key') for r in sites];check(None not in instances and len(set(instances))==3014,'ui-instance-duplicates')
for r in sites:
 check(bool(r.get('status')) and 'pending' not in r['status'],'ui-missing-disposition',r.get('id'))
 check((ROOT/r['file']).exists(),'ui-unknown-source',r['file'])
 check(filehash(ROOT/r['file'])==r['sha256'],'ui-source-hash',r['file'])
routes=csvrows('report/routes-and-ui.csv');check(len(routes)==3109,'ui-csv-count')
requirements=read('requirements/requirements.json');check(len(requirements)==1557,'requirement-traces')
findings=read('report/findings.json')['findings'];ids=[r['id'] for r in findings];check(len(ids)==len(set(ids))==87,'finding-duplicates/count')
for row in findings:
 for e in row['evidence']:
  path=e.get('path') if isinstance(e,dict) else e
  if not path:continue
  p=ROOT/path.replace('\\','/').split('#',1)[0]
  check(p.is_file(),'finding-missing-evidence',{'id':row['id'],'path':path})
  if p.is_file() and isinstance(e,dict) and e.get('sha256'):check(filehash(p)==e['sha256'],'finding-evidence-sha',{'id':row['id'],'path':path})
groups=read('remediation-groups.json');gids={g['id'] for g in groups};mapping=[i for g in groups for i in g['findings']]
check(set(mapping)==set(ids) and len(mapping)==len(ids),'remediation-coverage')
for g in groups:check(set(g['dependencies'])<=gids,'unknown-plan-dependency',g['id'])
required=['README.md','baseline.md','architecture.md','business-processes.md','routes-and-ui.csv','api-and-jobs.csv','role-permission-matrix.csv','tests.md','findings.md','findings.json','security.md','performance.md','mobile.md','operations.md','documentation.md','remediation-plan.md','coverage-gaps.md','completion-check.md']
for name in required:check((OUT/'report'/name).is_file(),'missing-report',name)
check((OUT/'requirements/requirements.csv').is_file(),'missing-requirements-csv')
result={'status':'COVERAGE_REGISTRY_PASS' if not errors else 'FAIL','census':len(cp),'own_text':len(own),'backend_modules':len(read('backend/module-registry.json')),'production_process_modules':len(read('backend/process-module-catalog.json')),'registered_endpoint_patterns':len(read('backend/registered-endpoints.json')),'api_operations':read('backend/behavior-link-summary.json')['api_operations'],'jobs':len(read('backend/job-registry.json')),'routes':95,'ui_instances':len(sites),'requirement_statement_traces':len(requirements),'findings':len(findings),'errors':errors,'boundary':'Structural coverage and immutable reference checks only. No all-role/all-state runtime or external target/security/provider/native acceptance. Report final wording, safe packaging and local commit remain separate completion steps.'}
(OUT/'completion-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=True))
if errors:raise SystemExit(1)
