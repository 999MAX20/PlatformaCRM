from pathlib import Path
import json,hashlib,csv,collections
root=Path.cwd();out=root/'output/full-audit-20261104/ui';issues=[];hashes={}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
 if p not in hashes:hashes[p]=hashlib.sha256(p.read_bytes()).hexdigest()
 return hashes[p]
def evidence(e,owner):
 if not isinstance(e,dict) or 'path' not in e:return
 p=root/e['path'].split('#',1)[0]
 if not p.is_file():issues.append({'owner':owner,'missing':str(p.relative_to(root))});return
 if e.get('sha256') and digest(p)!=e['sha256']:issues.append({'owner':owner,'hash_mismatch':e['path']})
sites=read(out/'action-state-reconciled.json');findings=read(out/'confirmed-findings.json')['findings'];inv=read(out/'inventory-current.json');native=read(out/'inventory-historical.json');cand=read(out/'candidate-adjudications.json')['rows'];register=read(out/'runtime-scenario-register.json')
assert sites['indexed_sites']==3014 and sites['unique_instance_keys']==3014 and sites['unique_site_keys']==3013
issues+=sites['issues']+[{'missing':x} for x in sites['missing_references']]
for r in sites['rows']:
 if digest(root/r['file'])!=r['sha256']:issues.append({'changed_source':r['file']})
 for e in r.get('resolved_evidence',[]):evidence(e,r['instance_key'])
for f in findings:
 for key in ['id','category','severity','priority','status','version','scope','requirement','expected','actual','reproduction','evidence','impact','recommendation','dependencies','acceptance']:
  if key not in f:issues.append({'finding':f['id'],'missing_field':key})
 for e in f.get('evidence',[])+f.get('current_extension',{}).get('evidence',[]):evidence(e,f['id'])
 if f['id'] in ['MOB-H04','MOB-H05'] and f['version']['head']!='73482a3bea7f168113c58d8cb928214c97f032d5':issues.append({'native_revision':f['id']})
for r in inv:
 if r['status']=='full_read_pending_dependency_and_runtime_trace':issues.append({'unfinished_file':r['path']})
 if r['status'].startswith('full_read_'):
  if digest(root/r['path'])!=r['sha256']:issues.append({'changed_source':r['path']})
  if {n for a,b in r['read_ranges'] for n in range(a,b+1)}!=set(range(1,r['line_count']+1)):issues.append({'range':r['path']})
for r in cand:
 if r['status']=='specific_followup_pending':issues.append({'pending_candidate':r['id']})
for name in ['coverage-validation.json','source-diff-validation.json','vite-source-review-validation.json','evidence-reuse-validation.json','routes-ui-export-validation.json','runtime-shutdown.json']:
 if read(out/name)['status']!='PASS':issues.append({'failed_receipt':name})
with (out.parent/'report/routes-and-ui.csv').open(encoding='utf-8-sig',newline='') as f:csvrows=list(csv.DictReader(f))
assert collections.Counter(r['row_type'] for r in csvrows)=={'route':95,'action':2279,'state':735}
assert len(register['scenarios'])==37
result={'status':'FAIL' if issues else 'PASS','boundary':'Evidence/source/schema/count/reconciliation integrity only. Not new product/runtime acceptance; failed product checks and explicit restricted/external/device scopes preserved.','routes':95,'render_cases':1140,'parameter_role_cases':276,'settings_cases':55,'action_state_instances':3014,'unique_site_keys':3013,'restricted_or_external_command_instances':sites['counts']['reviewed_source_with_explicit_runtime_boundary']+sites['counts']['static_reviewed_protected_runtime_limit'],'current_direct_text_files':sum(r['status'].startswith('full_read_') for r in inv),'native_files':len(native),'raw_candidates':len(cand),'untriaged_candidates':0,'ui_finding_records':len(findings),'scenario_groups':len(register['scenarios']),'csv_rows':len(csvrows),'issues':issues}
(out/'final-ui-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False));raise SystemExit(bool(issues))
