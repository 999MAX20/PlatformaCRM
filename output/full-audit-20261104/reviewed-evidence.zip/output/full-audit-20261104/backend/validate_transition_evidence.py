import hashlib
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
rows = json.loads((OUT/'semantic-transition-registry.json').read_text(encoding='utf-8'))
tests = {t['test_id']: t for t in json.loads((OUT/'test-assertion-matrix.json').read_text(encoding='utf-8'))}
errors = []
sources = set()
for row in rows:
    for location in row['implementation']:
        path = ROOT/location['path']
        sources.add(location['path'])
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['source_sha256']:
            errors.append([row['id'], 'source hash mismatch', location['path']])
        lines = path.read_text(encoding='utf-8-sig').splitlines()
        if '\n'.join(lines[location['decorator_start_line']-1:location['end_line']]) != location['guard_and_effect_source']:
            errors.append([row['id'], 'source range mismatch'])
    for receipt in row.get('reviewed_existing_scenarios', {}).get('test_receipts', []):
        actual = tests.get(receipt['test_id'])
        if not actual or receipt['execution'] != actual['execution'] or receipt['assertions'] != actual['assertions']:
            errors.append([row['id'], 'test receipt mismatch', receipt['test_id']])
    for receipt in row.get('executed_state_cases', []) + row.get('focused_cases', []):
        path = ROOT/receipt['log']
        if hashlib.sha256(path.read_bytes()).hexdigest() != receipt['log_sha256']:
            errors.append([row['id'], 'log hash mismatch'])
        line = path.read_text(encoding='utf-8', errors='replace').splitlines()[receipt['line']-1]
        if not line.startswith(('STATE_EDGE ', 'ALERT_EDGE ')):
            errors.append([row['id'], 'case log line mismatch'])
    if row['edge_evidence_status'] in ('associated_tests_require_case_review', 'missing_focused_edge_test'):
        errors.append([row['id'], 'unreviewed graph'])
summary = {'commands': len(rows), 'entities': len({r['entity'] for r in rows}), 'source_files': len(sources), 'statuses': dict(Counter(r['edge_evidence_status'] for r in rows)), 'errors': errors,
           'boundary': 'Source/hash/range and named scenario evidence integrity; no exhaustive guard-product, live provider, or new authorization certification.'}
(OUT/'semantic-transition-validation.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary))
raise SystemExit(bool(errors))
