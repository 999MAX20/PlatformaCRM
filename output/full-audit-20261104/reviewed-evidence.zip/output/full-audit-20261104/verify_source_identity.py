"""Check the original product snapshot, allowing only exact own prefix receipts."""
import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from doc_identity import matched

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="source-drift-current.json")
    args = parser.parse_args()
    target = OUT / args.output
    assert target.parent.resolve() == OUT.resolve()
    baseline = json.loads((OUT / "source-baseline.json").read_text(encoding="utf-8"))
    prefixes = {row["path"]: row for row in json.loads(
        (OUT / "requirements/current-prefix-reconciliation.json").read_text(encoding="utf-8"))}
    changes, errors = [], []
    for row in baseline["files"]:
        path = ROOT / row["path"]
        if not path.is_file():
            errors.append({"path": row["path"], "error": "missing"})
            continue
        actual = path.read_bytes()
        if digest(actual) == row["sha256"]:
            continue
        change = {"path": row["path"], "baseline_sha256": row["sha256"],
                  "current_sha256": digest(actual), "status": "unreconciled"}
        receipt = prefixes.get(row["path"])
        if matched(row['path'],row['sha256'],digest(actual)):
            change['status']='exact-reviewed-own-document-delta'
        if receipt and receipt["current_sha256"] == digest(actual):
            original = Path(receipt["baseline_path"]).read_bytes()
            original_lines = original.decode("utf-8-sig").splitlines()
            current_lines = actual.decode("utf-8-sig").splitlines()
            if digest(original) == receipt["original_sha256"] and current_lines[-len(original_lines):] == original_lines:
                change["status"] = "exact-original-body-with-own-prefix"
        changes.append(change)
        if change["status"] == "unreconciled":
            errors.append(change)
    current_paths = set(subprocess.check_output(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=ROOT
    ).decode().split("\0")) - {""}
    old_paths = {row["path"] for row in baseline["files"]}
    new_paths = sorted(current_paths - old_paths)
    result = {"time_utc": datetime.now(timezone.utc).isoformat(),
              "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
              "baseline_head": baseline["head"], "checked": len(baseline["files"]),
              "changes": changes, "new_nonbaseline_paths": new_paths, "errors": errors,
              "status": "PASS" if not errors and not new_paths else "REVIEW_REQUIRED",
              "boundary": "Original tracked/nonignored product/config/test/doc inputs; ignored census identity has separate global receipt. New files require explicit ownership/classification, never automatic acceptance."}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: result[key] for key in ["status", "checked", "changes", "new_nonbaseline_paths", "errors"]}))


if __name__ == "__main__":
    main()
