# Current applicability of two historical frontend findings

Root read current monitoring.ts, useInboxDraft.ts, storage.ts, main.tsx and the
reset/invitation public-route declarations, plus the preserved synthetic receipts
and the seven-file SHA comparison. No new protected experiment was run.

FU-FE-01 remains a narrow Low/P3 legacy-data privacy issue. The hook's fallback
imports a business/conversation-only draft into the current user's namespaced key.
The legacy format contains no creator identity; tokenStorage.clear removes tokens,
email and Lead offline storage, but does not remove this Inbox legacy key. Prior
actual-hook execution imports actor101's synthetic draft into actor202's key;
the positive control leaves a correctly namespaced actor101 draft isolated.
Required conditions: old-format data retained in the same tab/browser profile and
the later actor can lawfully open the same Business/conversation. No remote leak,
cross-Business bypass or actual browser login chain was executed by that receipt.

FU-FE-02 remains Conditional Medium/P2 telemetry exposure. main initializes
monitoring before Router; optional Sentry init supplies no sensitive-URL scrubber.
The current router still carries reset and invitation bearer values in paths.
The prior installed-SDK10.56.0 in-memory transport retained a synthetic reset token
in captured request.url with zero external requests. The seven relevant source
hashes and installed SDK version match; route declarations moved without removing
the bearer paths. Deployment DSN, actual ingestion, useful token lifetime and
telemetry-recipient access are necessary conditions, not observed facts.

Keep both historical IDs in the new register, with current applicability and these
conditions. They were outside the earlier29-item register; that omission does not
make them new code regressions. Do not fold telemetry URL handling into server
exception redaction without retaining the different browser sink and preconditions.

Acceptance: legacy drafts cannot be silently assigned to an unproven creator;
normal current-user drafts still persist. Sensitive route values must be redacted
before every supported telemetry URL/breadcrumb/span sink, while diagnostics
retain useful route templates and error context. Use synthetic bearers and an
in-memory transport before any separately authorized deployed validation.

Evidence: ui/historical-security-reconciliation.json,
output/security-frontend-followup-20261027/legacy-draft-result.json and
monitoring-url-result.json. No actual secrets were used or disclosed.
