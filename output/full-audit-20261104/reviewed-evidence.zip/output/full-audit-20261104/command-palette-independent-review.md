# Command palette keyboard and accessible-name boundary

Root independently reviewed current CommandPalette.tsx (including full rendered
control tree), AppLayout registration references, the exact browser diagnostic
case and its JSON observations. Confirmed P2 accessibility issue: Ctrl+K opens a
screen-covering overlay, but it has no dialog semantics or contained focus loop.
After the six visible command buttons, actual Tab observations reach BODY and
background sidebar links while the palette remains open. The first focused close
button has no accessible name: source renders only an X icon without aria-label.
Escape closes successfully and is retained as a positive control.

This is the current EN desktop synthetic-owner browser case from
ui/drawer-search-probes-palette.json. It does not claim a screen-reader session or
every viewport. The adjacent GlobalSearch failure in the same file is a harness
timeout with no intercepted requests, so it is not evidence of a search recovery
defect. Later search-only retries have separate evidence. Simulated card pagination
metadata is also not used for this finding.

Future acceptance: a named modal/dialog or equivalent established accessible
interaction, a named close action, keyboard containment while open, Escape and
focus restoration, and command navigation with correct permissions. Check Tab
and Shift+Tab, empty/error/results states and the relevant responsive surface.
No product component was changed by this audit.
