# Independent review: campaign continuation and selected audience

Current source at d27044b1 plus recorded WIP. Root independently read the complete
three-observation probe, runner and final log, current preparation/launch/refresh
services, API actions and the reachable manual-audience controls/copy. No second
execution, real provider delivery or product changes are claimed.

## Batch continuation — confirmed P2

`services.py:323` creates notifications only for the first `batch_size` queued
recipients. Immediate launch enters running; subsequent launch accepts only ready
or scheduled. Refresh leaves running while queued recipients remain and never
creates their notifications. Current caller search and registered job inventory
contain no continuation caller. The isolated two-recipient/batch-one observation
advances only the first synthetic notification to sent, then proves one queued
recipient and rejected relaunch. Retry-failed cannot rescue a fully successful
first batch because no failed recipient exists.

This also conflicts with current integrations AC-CAMPAIGN continuation/recovery
requirements. The English label says "Batch per launch", but a later ordinary
launch is blocked; choosing a small launch batch does not supply a working
continuation mechanism. This is not proof of provider failure or total loss of
all messages. Acceptance: every selected eligible recipient progresses exactly
once across multiple batches, controlled rate, restart/retry and terminal state.

## Manual audience replacement — confirmed P2

Prepare A; change the UI selection to only B; prepare again. The service uses
update_or_create for B but retains A. The executable observation records two
recipients for one selected client. Current UI exposes toggles and submits the
complete selected IDs to the prepare action; copy identifies them as the selected
manual audience. It does not describe incremental additions. API role checks and
Business-scoped client selection remain in place: no tenant bypass is asserted.

Launch subsequently iterates all queued recipients, so deselected A remains
eligible for notification creation. No actual unintended message was sent in
the audit. Consent checks are a separate safeguard and do not restore the user's
chosen audience. Acceptance: replace pending manual audience atomically with the
selected eligible set, preserve delivered history, and test deselection, empty
selection, consent changes and repeated preparation before launch.

Evidence: `backend/probe_functional_gaps.py`,
`backend/run_functional_gaps.py`, `backend/functional-gap-observations.log`.
All three observations passed by asserting existing behavior; that is reproducer
success, not product acceptance. Disposable SQLite with environment-file loading
suppressed, synthetic keyring and guarded sockets. The third hours-overwrite
observation still needs policy/UI reconciliation and is not promoted here.
