# Search failures and client-card continuation

## Global search hides two source failures

Confirmed P2. Root read the actual UI receipt, probe's interception path,
GlobalSearch data/query and final rendering branches, and useEntityData queries.
Task/conversation queries return normal React Query result objects; the search
maps absent data to empty arrays and renders errors only for Clients/Records.
The empty condition likewise ignores tasks.error and botConversations.error.

The final search-only browser receipt records four actual intercepted requests
to tasks/bot-conversations returning503, followed by "Nothing found in CRM data",
zero alerts and zero Retry buttons. The earlier no-interception locator timeout
does not prove this defect and is preserved separately. This finding concerns
truthful partial-source failure feedback; it adds to UI02's first-page search
coverage defect without treating the two mechanisms as identical.

Acceptance: a failed source must not be presented as a complete negative search;
successful-source results remain usable with source-aware retry/recovery and
accurate loading/partial/error states. Test both failed sources independently,
mixed success, empty success and recovery.

## Client tasks panel stops at25 despite count26

Confirmed P2. Root read complete client-card-pagination.cjs and its real API/UI
receipt, complete EntityTasksPanel.tsx, and backend count/limit/slicing references.
The isolated owner created one Client and26 Tasks via actual API. The card returned
25 with related_counts.tasks26 and has_more.tasks=true. The UI tab displays26,
but its content contains25 individual task links and only Create task; no full-list
or continuation action. Source only renders its has_more link for appointment
entities, excluding this Client path.

The earlier metadata-only simulation is not used as backend evidence. This actual
fixture proves the Client→Tasks case. No task was
deleted; it can still be reached through the global Tasks workflow. The defect is
an incomplete client-context path with no way to continue from that panel.
Acceptance: clearly indicate truncation and offer permission-preserving full list
or pagination, retaining client context. Cover25/26 rows, sparse filtered visibility,
empty results and navigation back. Related tabs require their own applicable cases.

The subsequent actual API/UI check extends this finding to the same Client's
Appointments, Conversations and Deals tabs. Root read the complete fixture builder,
browser diagnostic, metadata/control observations and all three rendered panel
components. Each API list returns25 of26 with has_more=true. Appointments offers
25 entity links but no continuation; Conversations and Deals offer no links or
buttons. All three panels ignore has_more. The26-per-domain rows were inserted
only into guarded audit.sqlite3 using ORM: this proves projection/navigation,
not domain creation or lifecycle correctness. bot_enabled is false and no message
was sent. Exact evidence: ui/related-card-pagination.json and
ui/related-pagination-fixture.json. Other parent entity cards are not extrapolated.

Receipts: ui/drawer-search-probes-retry.json (search-only),
ui/client-card-pagination.json and its screenshot. Source hashes are covered by
the unchanged current input manifest; no product fix or new root runtime claimed.
