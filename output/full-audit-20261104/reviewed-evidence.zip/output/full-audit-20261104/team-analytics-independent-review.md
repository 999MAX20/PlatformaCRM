# Independent review: TEAM analytics source visibility

Root independently reviewed the complete isolated probe and runner, its final
result log, `apps/businesses/views.py` source-query construction (491–530) and
loss-reason projection (693–715), and `docs/current/access.md` 285–300.
Baseline is d27044b1 plus preserved WIP; no second active probe was run.

Confirmed authorization defect, P1/high confidentiality impact within a Business:
an active manager with Analytics VIEW receives an assigned Lead count and its
literal free-text loss reason through `/api/team/performance/` after explicit
Lead VIEW denial or disabling the leads module. The ordinary Lead list returns
zero records for both cases. Team-member filtering and Business filtering do not
implement the required source-resource permission/capability intersection.

The probe includes an allowed-source positive control and a foreign-Business
403/foreign-reason-absence control. Therefore this evidence establishes an
intra-Business source visibility bypass, not cross-tenant disclosure. It does
not establish the same outcome for Deal/Task/Appointment fields, even though
their raw query construction warrants separate review. The source uses bounded
date filters and top-five loss reasons; those bounds limit output volume but
do not authorize the disclosed values.

`backend/team-visibility-probe-1793741027.log` records one successful reproducer
test in 2.038 seconds and disposable DB destruction. Its assertions deliberately
expect the vulnerable result; this is defect reproduction, not acceptance PASS.
The initial fixture failure remains in the earlier log. Synthetic data only,
network-connect guard, isolated_runtime environment; no working DB mutation.
The runner did not suppress settings' `.env` read: explicitly overridden DB and
provider fields remain isolated, but absent environment keys could be loaded.
The probe blocks socket.connect and exercises only local source projections.
It is not proof of a completely hermetic process. Future diagnostics use the
existing audit-only read_env/socket guard; this limitation is retained here.

Acceptance for a future fix: each derived metric intersects current source VIEW,
object scope and capability before aggregation. Preserve permitted independent
resources and team/member/date semantics. Cover allowed, denied, disabled,
OWN/TEAM scope and foreign-Business cases, with free text and counts both absent
when the source is unreadable. No new permission policy is needed: the current
access contract explicitly requires this behavior. No fix was made in this audit.
