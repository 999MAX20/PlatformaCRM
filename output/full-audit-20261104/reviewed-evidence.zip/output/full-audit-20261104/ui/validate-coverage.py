from pathlib import Path
import json,hashlib,subprocess,collections
out=Path(__file__).parent;root=out.parents[2]
direct_statuses={'full_read_pending_dependency_and_runtime_trace','full_read_semantic_reconciled_scoped_evidence','full_read_tooling_test_contract_reviewed'}
def digest(b):return hashlib.sha256(b).hexdigest()
a=json.loads((out/'inventory-current.json').read_text());hist=json.loads((out/'inventory-historical.json').read_text());maps=json.loads((out/'historical-byte-map.json').read_text());issues=[]
for r in a:
 p=root/r['path']
 if not p.exists():issues.append({'path':r['path'],'issue':'missing'});continue
 if digest(p.read_bytes())!=r['sha256']:issues.append({'path':r['path'],'issue':'hash_changed'})
 if r['status'] in direct_statuses:
  covered=set()
  for lo,hi in r['read_ranges']:covered.update(range(lo,hi+1))
  if covered!=set(range(1,r['line_count']+1)):issues.append({'path':r['path'],'issue':'incomplete_direct_ranges'})
for r in hist:
 b=subprocess.check_output(['git','show',r['revision']+':'+r['path']],cwd=root)
 if digest(b)!=r['sha256']:issues.append({'path':r['path'],'issue':'historical_hash_changed'})
 if r['read_ranges']!=[[1,r['line_count']]]:issues.append({'path':r['path'],'issue':'historical_ranges_not_full'})
for r in maps:
 raw=(root/r['path']).read_bytes();lines=raw.splitlines();coverage=set()
 for b in r['exact_byte_blocks']:
  src=(root/b['canonical_path']).read_bytes();lo,hi=b['historical_range'];cl,ch=b['canonical_range']
  if digest(src)!=b['canonical_sha256'] or lines[lo-1:hi]!=src.splitlines()[cl-1:ch]:issues.append({'path':r['path'],'issue':'reference_mismatch','range':[lo,hi]})
  coverage.update(range(lo,hi+1))
 for lo,hi in r.get('delta_read_ranges',[]):coverage.update(range(lo,hi+1))
 if coverage!=set(range(1,len(lines)+1)) and r['status']!='generated_artifact_provenance_verified':issues.append({'path':r['path'],'issue':'historical_coverage_gap'})
def fail(path,issue):issues.append({'path':path,'issue':issue})
def validate_ranges(path,ranges,count,full=False):
 covered=set();valid=True
 if not isinstance(ranges,list):fail(path,'missing_ranges');return False
 for pair in ranges:
  if not isinstance(pair,list) or len(pair)!=2 or any(type(v)is not int for v in pair):fail(path,'malformed_range');valid=False;continue
  lo,hi=pair
  if not 1<=lo<=hi<=count:fail(path,'range_out_of_bounds');valid=False;continue
  covered.update(range(lo,hi+1))
 if full and covered!=set(range(1,count+1)):fail(path,'incomplete_direct_ranges');valid=False
 return valid
def full_receipt(r):
 raw=(root/r['path']).read_bytes();count=len(raw.splitlines())
 valid=digest(raw)==r.get('sha256') and count==r.get('line_count')
 if not valid:fail(r['path'],'invalid_direct_hash_or_count')
 return validate_ranges(r['path'],r.get('read_ranges'),count,True) and valid
direct={}
allowed={'full_read_pending_dependency_and_runtime_trace','historical_content_reviewed_by_exact_references_and_delta','metadata_inventoried','binary_validated_usage_checked','generated_artifact_provenance_verified','secret_schema_reviewed_values_protected'}
allowed.update(direct_statuses)
for r in a:
 if r.get('status') not in allowed:fail(r['path'],'unknown_current_status')
 if r.get('status') in direct_statuses and full_receipt(r):direct[r['path']]=r
rootrows=json.loads((out.parent/'root-review.json').read_text(encoding='utf-8'))
for r in rootrows.values():
 if r.get('status')=='full-read-static-reviewed' and r.get('review_note') and full_receipt(r):direct[r['path']]=r
for r in hist:
 raw=subprocess.check_output(['git','show',r['revision']+':'+r['path']],cwd=root)
 if r.get('status') not in {'full_read_pending_dependency_and_runtime_trace','full_read_historical_semantics_and_function_probes'}:fail(r['path'],'unknown_native_status')
 if len(raw.splitlines())!=r['line_count']:fail(r['path'],'native_line_count')
 validate_ranges(r['path'],r.get('read_ranges'),len(raw.splitlines()),True)
proofs={r['path']:r for r in json.loads((out/'gallery-provenance.json').read_text())};grouped={}
for r in maps:
 path=r['path'];raw=(root/path).read_bytes();lines=raw.splitlines()
 if digest(raw)!=r.get('sha256') or len(lines)!=r.get('line_count'):fail(path,'group_hash_or_count')
 if not r.get('semantic_note','').strip():fail(path,'missing_semantic_note')
 if r.get('status') not in {'historical_content_reviewed_by_exact_references_and_delta','generated_artifact_provenance_verified'}:fail(path,'unknown_group_status')
 if not r.get('copies'):fail(path,'missing_copies')
 for copy in r.get('copies',[]):
  if digest((root/copy).read_bytes())!=r['sha256']:fail(copy,'copy_hash_mismatch')
  if copy in grouped:fail(copy,'duplicate_group_membership')
  grouped[copy]=r
 validate_ranges(path,r.get('delta_read_ranges',[]),len(lines))
 for b in r['exact_byte_blocks']:
  src=(root/b['canonical_path']).read_bytes();lo,hi=b['historical_range'];cl,ch=b['canonical_range']
  validate_ranges(path,[b['historical_range']],len(lines));validate_ranges(b['canonical_path'],[b['canonical_range']],len(src.splitlines()))
  if hi-lo!=ch-cl:fail(path,'block_line_count_mismatch')
  if b['canonical_path'] not in direct:fail(path,'canonical_without_direct_full_read:'+b['canonical_path'])
  if digest(b''.join(lines[lo-1:hi]))!=b.get('bytes_sha256'):fail(path,'block_bytes_hash_mismatch')
 if r.get('status')=='generated_artifact_provenance_verified':
  proof=proofs.get(path)
  if not proof or proof.get('exactBytesEqual') is not True:fail(path,'missing_exact_generation_proof');continue
  for key,hashkey in [('path','sha256'),('generator','generatorSha256'),('source','sourceSha256')]:
   if digest((root/proof[key]).read_bytes())!=proof.get(hashkey):fail(path,'generation_proof_hash:'+key)
  if proof.get('bytes')!=len(raw):fail(path,'generation_byte_count')
for r in a:
 if r.get('status') in {'historical_content_reviewed_by_exact_references_and_delta','generated_artifact_provenance_verified'}:
  group=grouped.get(r['path'])
  if not group or group.get('status')!=r['status']:fail(r['path'],'missing_or_inconsistent_group')
report={'boundary':'Read-ledger hash/range/direct-read/reference/provenance validation only; no route or action runtime acceptance implied','status':'FAIL' if issues else 'PASS','currentStatuses':dict(collections.Counter(r.get('status') for r in a)),'historicalNative':len(hist),'historicalGroups':len(maps),'directSources':len(direct),'issues':issues}
(out/'coverage-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
raise SystemExit(bool(issues))
