# Independent routing and pipeline follow-up

Root reviewed current source on the audit working snapshot, and the entire
`backend/probe_final_functional.py` plus `backend/final-functional-observations.log`.
The first batch has three successful observation tests and one fixture failure
(`eq` is not a supported operator); this is not an all-green batch.

- `apps/businesses/routing.py:188–215` selects only active unassigned work, but
  `105–155` reloads under lock without repeating the active-state predicate.
  The deterministic ORM interleave changes a selected task to `done` before the
  real locked service. Assignment still occurs. This corroborates a lifecycle
  race, not a PostgreSQL parallel-load or authorization-bypass proof.
- `routing.py:219–289` decides fallback eligibility from a pre-lock assignee.
  After locking, it checks only that the current assignee is nonempty and differs
  from the fallback. It does not require the original unavailable assignee.
  The interleave manually assigns a different active member; fallback then
  overwrites that assignment. The missing compare/recheck is independently
  visible in source. Repair should re-evaluate state/assignee/policy at the
  write boundary; retain explicit manual reassignment.
- `apps/conversations/pipeline.py:412–474` reuses tasks by metadata ID or matching
  links/title while excluding done/cancelled, but neither branch excludes archived
  tasks. The real helper returns an archived open task and creates no replacement.
  Evidence is helper-level, not an exercised full confirmation UI. Acceptance
  should cover both reuse branches and an archived versus active control.

Also independently read `ui/inbox-browser-retry.json` and
`ui/attachment-browser-retry.json`: actual UI request receipts corroborate the
previous root source reviews. Inbox restores A's draft after B succeeds but sends
A with a different key. Attachment retry sends both files after one succeeded
and the other failed. All corresponding POSTs were intercepted; there is no
claim of observed duplicate external delivery, scanner bypass or real file upload.

No product change or additional runtime was performed by this review.
