# Independent review: segment creation cannot recover after a partial save

Confirmed current functional recovery defect, priorityP2. Root read the complete
browser diagnostic/result, ClientsPage creation mutation, full segment dialog,
shared query defaults and API adapter, and backend Segment model/serializer,
evaluate/refresh handlers and selector.

The UI issues three separate requests: create active Segment, create its filter,
refresh cached count. A503 on the second request leaves the first write committed.
Retry starts at creation again and receives400 for the same unique business/name/
entity tuple. The dialog retains the input but neither displays mutation.error nor
provides a way to resume the newly created segment. Shared QueryClient defaults
do not install a mutation error handler for this form.

`ui/segment-recovery.json` records201→503→400, one persisted segment, zero filters,
cached_count0 and retained dialog before/after retry. A network fault was injected
only into the filter request; actual Segment creation/read and duplicate rejection
used the isolated backend. No working data or external effects were involved.

Do not interpret cached_count0 as proof that this segment matches zero clients:
`evaluate_segment_queryset` with no filters starts from all non-archived clients
in its Business, while count refresh was never reached. This diagnostic establishes
incomplete active configuration and failed retry, not client-record deletion or
an executed campaign against unintended recipients. Source-permission bypass is
not asserted: Segment endpoints map to Clients permissions and tenant scope.

Acceptance for a future change: complete segment+filter persistence atomically,
or explicitly retain/resume the partial object's identity with truthful recovery.
Invalid filter or failure must not leave a silently active incomplete segment;
retry/unknown response must not duplicate configuration. Test second-step failure,
count-refresh failure, safe retry, visible validation, role/tenant denial, and one
complete segment/filter on success. No product changes were made in this audit.

## Separate input-shape defect

Root independently read `backend/probe_final_functional.py` completely and the
focused final-functional-recheck.log result/trace, plus complete segments.py,
serializers.py130–185, views.py86–124 and models.py103–167. Owner API accepts
`value_json: ["website"]` with201. Evaluation calls `.get()` on that list and
returns500. Updating the same row to `{"value":"website"}` produces200.
The serializer validates Business/segment linkage and sensitive-field visibility
but does not validate the JSON shape expected by the evaluator. This is P2 input
validation/recovery, separate from the UI multi-request partial-save defect above.

The corrected focused test passes because it asserts the faulty201→500 behavior;
it is not acceptance. The earlier invalid operator fixture is retained in the
original batch log. No permission bypass or production incident is asserted.
Future acceptance: reject invalid list/scalar/null shapes at create/update with
400 before persistence, preserve valid supported filters, and handle any retained
invalid rows without an unhandled500 in evaluate/count refresh. Prove both writes
and both consumers, in addition to the existing tenant/field-policy checks.
