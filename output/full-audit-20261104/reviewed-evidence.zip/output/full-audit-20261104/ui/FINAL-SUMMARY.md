# UI/mobile audit — final scoped evidence

The source, route and action/state audit is reconciled for the preserved
`d27044b1` working snapshot. Product defects remain open; this is not a release,
all-state runtime, live-provider or native-device acceptance certificate.

## Coverage and evidence

- **944 current text files** fully read:704 product source/widget and240
  tooling/test/configuration contracts. Original hashes and full read ranges remain
  in `inventory-current.json`; no current direct-read item remains pending.
- **653 historical/captured files** reconciled through219 distinct byte/delta
  groups, plus44 immutable historical native files. Metadata61, binary4,
  generated2 and protected-secret-schema1 items retain their distinct treatment.
- **95 declared routes**,1140 locale/viewport render cases,276 parameter/role
  supplement cases and54 settings-section renders plus one Billing503 recovery.
  These are different denominators. Render cases are not command tests.
- **3014 action/state AST instances**:2279 handlers and735 declarations. There are
  3013 site hashes because two same-line SupportDetail callbacks share source,
  expression and line; occurrence0/1 preserves both instances.
- All205 raw candidates have explicit dispositions. Forty UI/native/security
  finding records retain prior UI01–12/MOB-H01–03 and FU-FE identifiers; UI14 is an
  alias of backend `ATTACHMENT-RETRY` for root consolidation, not another defect.
- `report/routes-and-ui.csv` contains95 route rows and3014 exact action/state
  rows. `action-state-reconciled.json` joins source/caller/dispatch review,
  representative actual or source-identical prior evidence, and explicit limits.
- **99 actual command instances** retain protected or external execution limits
  (74 UI subset +25 platform/account/support subset). Ordinary editor inputs,
  local state, navigation and read retries are not classified as environment gaps.
  The ledger does not claim3014 independent live clicks or every role combination.

## Material findings

The prior outer error-boundary recovery failure remains. New current observations
include logout503 restoring the cookie-backed session after reload; partial
attachment retry resending an accepted file; Inbox retry losing its original
idempotency identity after another conversation sends; segment partial creation
without a useful retry; and stale duplicate warnings replacing newer lookup results.

Client drawer, Inbox and pricing history omit continuation beyond API page limits.
The full client page renders all26 related fixture rows and is not included in the
drawer25/26 truncation claim. Several drafts disappear on tab/browser navigation,
successful earlier saves or a changed service GET response after reconnect.
Schedule exception success can open affected-appointment review for the newly
selected date instead of the submitted date.

Additional findings cover unknown-versus-zero/control-state display, missing read
recovery, misleading role actions with a correctly enforcing backend403, menu
visibility/focus semantics, business-day grouping and product-owned localization.
Website capture has failed-send/storage recovery and growing-history layout issues;
two-way chat remains optional and is not classified as missing V1 implementation.

`confirmed-findings.json` gives expected/actual behavior, severity, impact,
recommendation, acceptance and hashed evidence for each record. Static conditional
copy and historical security findings are explicitly distinguished from fresh
runtime observations. Original failed harness/suite runs remain present; corrected
focused checks do not turn those original runs green.

## Verification and limitations

Read/hash/range/provenance validation passed with1617 direct source receipts,
44 native files and219 historical groups. The6411-line preserved source diff and
six Vite captures passed their exact-reference validators. Prior reuse verifies
1946 product inputs and706 frontend snapshot inputs unchanged.

Records/VisitPlan reuse has an additional explicit proof: PlanEditor, PlanHistory,
catalog/API and backend plan sources match the old audit; VisitPlansPage differs
only by the reviewed create-capability guard and appointment return context and
matches the later remediation snapshot. Named create/revise/archive/restore,
schedule and corrected recovery receipts are reused without reusing unrelated
old failures as current success.

No new protected authentication/MFA/ownership/permission attack probes were run.
External provider/model/payment delivery and actual repricing are not certified.
Historical native source is revision
`73482a3bea7f168113c58d8cb928214c97f032d5`; transpiled functions and in-memory ORM
adapters do not prove Android/iOS integration, notifications, emulator/device
behavior or store publication.

No product changes, working-database writes, dependency installation, push or
deployment were made by this UI audit. Mutating ordinary browser probes used
the isolated database or explicitly intercepted responses; external network was
blocked. Prior build/type results are reused only on the verified unchanged inputs.

The isolated runtime was stopped after all users of it completed: backend launcher
19568 and verified child18216, frontend9956. No remaining task process or listener
on51773/51774 was observed (`runtime-shutdown.json`). Other development processes
were not stopped.
