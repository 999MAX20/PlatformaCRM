# Root independent review of remaining UI observations

Snapshot d27044b1 with preserved WIP. This is source and retained-receipt review,
not an additional browser execution. No product changes.

## Unsaved note discarded on tab switch — P2

Read full drawer-draft-controls.cjs and its JSON. The actual authenticated client
drawer receives an unsaved note, switches to Overview and back, and returns an
empty textarea with no alert. The single dialog is the existing drawer, not an
unsaved-change confirmation. EntityNotesPanel stores text only in component
useState; CrmEntityDrawer replaces this component when activeTab changes. There
is no draft preservation or guard in that path. Only unsaved text is lost; saved
notes were not deleted. The shared component suggests wider reach, but runtime
proof is one client drawer. Acceptance: retain the draft for the same entity or
explicitly confirm discard; verify save, failure, tab return and entity change.

The Textarea call supplies placeholder only. Its wrapping label contains no
label text, and the retained aria snapshot has an unnamed textbox. Treat this
as a separately scoped accessibility issue, not the cause of draft loss.

## Appointment empty-state copy — P3

The same probe selected client6 after the real crm-card API reported zero
appointments. Its Overview displayed “Client tasks will be visible here.”
client.tsx163 uses crmCard.noTasksText for an empty appointment summary. This is
wrong subject copy, not absent task data or a server bug. Acceptance: an
appointment-specific empty state in RU/KK/EN. The similar historical lead drawer
line is not added as a reachable runtime defect without its own caller proof.

## Built-in automation templates remain Russian — P2

Read full locale-visible-followup.cjs and all seven JSON results. Preferences
and browser language were set to RU/KK/EN; surrounding controls changed language,
but built-in names/descriptions remained Russian in KK/EN. apps/automations/views.py
defines those literals; AutomationTemplates.tsx50–53 renders them directly.
These are system templates, not user-authored names. Acceptance: translated
built-in display values without rewriting user-created rules. The separately
observed pilot NotFound narrative and API/Django Admin empty-pipeline instruction
are current content observations; they are not folded into this localization ID.

## Conversation list truncates at first page — P2

Read full inbox-list-controls.cjs and the actual-list-pagination result. Real
isolated API returns count59, results50 and next page2. UI renders50 before and
after scrolling to the last item; available controls have no continuation.
useInboxQueries.ts54–65 requests one list page and takes results. This is distinct
from MESSAGE-CURSOR, which drops a message at history page boundaries. No stored
conversation deletion is claimed; filters can still expose subsets. Acceptance:
all59 conversations reachable through pagination/infinite continuation, with
filter reset and ordering checks, and correct end-of-list behavior.

These observations use synthetic isolated data and local browser responses.
They neither certify all drawer variants nor imply external message delivery.

## Resource save overwrites newer unsaved edit — P2

Read full resource-async-controls.cjs, initial result and successful no-branch
retry result, ResourceForm submission and ResourceEditModal caller. An intercepted
PATCH carries nameA; while its response waits, the actual field remains enabled
and accepts nameB. Response200 resets it toA. ResourceForm awaits onSubmit then
form.reset(values), where values is the submitted snapshot; the caller disables
only for permission/retirement, not isSaving. Resource invalidation/remount can
also replace local state, but that broader path is not needed for this proof.
No actual resource write occurred: the probe intentionally fulfilled PATCH.
Acceptance: preserve newer draft/revision or prevent editing during submission;
verify current-success, stale-success, failure and retry without silent loss.

The initial no-branch scenario failed on an obsolete button label before POST.
Its corrected retry captured POST503 and a visible error alert. Thus “no error
shown” is rejected, not added to findings. The saved default schedule requiring
an edit and Back staying enabled are separate observations; this review does
not infer an additional persisted-data defect from them.
