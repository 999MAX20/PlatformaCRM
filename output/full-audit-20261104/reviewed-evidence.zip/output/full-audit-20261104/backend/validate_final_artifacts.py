import hashlib
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
load=lambda name:json.loads((OUT/(name+'.json')).read_text(encoding='utf-8'))
errors=[]
findings=load('confirmed-findings')
required={'id','category','severity','priority','status','version','scope','requirement','expected','actual','reproduction','evidence','impact','recommendation','dependencies','acceptance','owner_decision'}
ids=[]
for row in findings:
    ids.append(row['id'])
    if required-row.keys():errors.append([row['id'],'missing fields',sorted(required-row.keys())])
    for receipt in row['evidence']:
        path=ROOT/receipt['path']
        if not path.is_file():errors.append([row['id'],'missing file',str(path)])
        elif receipt.get('sha256') and hashlib.sha256(path.read_bytes()).hexdigest()!=receipt['sha256']:errors.append([row['id'],'stale hash',str(path)])
    reproduction=ROOT/row['reproduction']['receipt']
    selector=row['reproduction']['selector']
    if selector and reproduction.suffix=='.json':
        text=reproduction.read_text(encoding='utf-8')
        for item in selector.split(';'):
            if item not in text:errors.append([row['id'],'missing receipt selector',item])
if len(ids)!=len(set(ids)):errors.append('duplicate finding IDs')
if {'DEAL-REQUESTLESS-AUDIT','BOOKING-RESPONSIBLE','PRICING-REAPPLY'}&set(ids):errors.append('nonnew/nonapplicable finding promoted')
review=load('candidate-applicability-review')
if len(review['reviews'])!=95 or len({r['id'] for r in review['reviews']})!=95:errors.append('candidate review count')
for row in review['reviews']:
    if hashlib.sha256((ROOT/row['source_path']).read_bytes()).hexdigest()!=row['source_sha256']:errors.append([row['id'],'candidate source drift'])
tests={t['test_id']:t for t in load('test-assertion-matrix')}
history=load('historical-security-current-reconciliation')
for row in history['rows']:
    for source in row['sources']:
        path=ROOT/source['path']
        text=path.read_text(encoding='utf-8-sig')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=source['sha256'] or '\n'.join(text.splitlines()[source['line']-1:source['end_line']])!=source['source']:errors.append([row['id'],'historical source mismatch',str(path)])
    for receipt in row['existing_tests']:
        actual=tests[receipt['test_id']]
        if receipt['execution']!=actual['execution'] or receipt['assertions']!=actual['assertions']:errors.append([row['id'],'test receipt mismatch'])
summary={'confirmed_new_findings':len(findings),'candidate_applicability_rows':len(review['reviews']),'historical_reconciliations':len(history['rows']),'prior_finding_aliases':len(load('prior-finding-additional-scenarios')),'errors':errors,'boundary':'Artifact fields, reference hashes, exact selectors, source snippets and existing-test joins; independent semantic review remains root responsibility.'}
(OUT/'final-artifact-validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
raise SystemExit(bool(errors))
