# Widget: independent source and browser review

Root read the complete frontend/widget/src/index.ts, ui/widget-runtime.cjs and
its three result modes; inspected widget-failed.png. Root separately executed
shared-ui/widget-extra.cjs against the unchanged source bundled in memory.
All requests were intercepted on a synthetic localhost page. No real message,
provider call or server mutation occurred. Current source SHA is in both receipts.

The bubble opens/closes and focuses the message field. Empty submit sends nothing.
While the first send is pending the button is disabled, Enter does not send twice,
and a newly typed second draft remains. On success the subsequent send uses the
returned conversation path and the same visitor ID; apiUrl trailing slash is
normalized. These are actual client-function observations, not backend delivery.

On503 the submitted text is cleared from the input and retained only as a user
bubble followed by a generic failure notice. There is no retry control or draft
restore. The claim is a recovery/usability defect; the notice is not false success
and the text remains available for manual copying. A later failed append does not
erase earlier successful messages or change the known conversation identity.

When localStorage.getItem is denied, getVisitorId throws before fetch; the same
generic error appears and zero requests occur. Repeated send cannot recover while
storage is denied. An in-memory visitor fallback or explicit supported-browser
limitation is needed; no cross-user disclosure is established.

At320x480, after the three controlled sends, the actual left panel is x22,y-282,
width290,height662. Header/earlier content extend above the viewport; Send remains
visible at y321. The right-position earlier screenshot also clips its header.
This is a bounded height/reading issue, not an assertion that all widget controls
are unreachable. Use viewport-constrained panel layout and scrollable history.

The source visibly mixes Russian content with English Send/Open labels and has
no locale option. Treat this separately from user-authored content. Escape not
closing is an observation; the panel does not claim modal semantics, so absence
of a modal focus trap alone is not classified as a defect.

Missing incoming-reply polling is **not** a V1 requirement defect: current
product.md62 and roadmap.md319 explicitly make two-way website chat optional.
The implemented boundary is website capture. No new real-time chat scope is
authorized by this audit.

Acceptance for recovery: first/append success,503/network/unknown outcome and
storage-unavailable cases preserve recoverable intent with clear status; retry
identity must not create duplicate accepted messages. For layout/localization,
verify supported locale and320/390/desktop in both positions with growing history.
