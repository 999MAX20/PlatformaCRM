# Independent review: notifications and health summary

Root read complete probe_operational_functional.py, actual observation records in
state-edge-recheck.log, personal_selectors.py1–150, scheduling/services.py632–661,
operations_health.py1–135,133–196,242–end.

**Appointment notification hidden, P2 confirmed.** The producer creates a system
work notification and recipient row with /app/appointments/{id}. notification_subject
recognizes only exact entity routes, including /app/calendar with an appointment
query parameter; the producer's path returns None. personal_states excludes that
notification, even for the current owner with readable appointment. The actual ORM
test proves recipient exists but feed excludes it; changing only action_url to the
recognized calendar route makes the same row visible. This is a missing notification,
not an authorization bypass. Another producer at services.py761 uses the same path;
its complete behavior has not been separately executed by this reproducer.

**Queue warning omitted from aggregate, P2 confirmed.** _queue_summary legitimately
returns warning for retries/due work/routing warnings, while platform_operations_health
adds queue critical only and omits queue warning from warning_count. With other
source summaries healthy, queue warning coexists with overall healthy. The probe
executes the aggregation with explicit isolated summary adapters; it does not inspect
a deployed environment or prove an actual missed incident. Detailed queue status is
still available, so impact is misleading aggregate status rather than hidden all data.

Acceptance: use recognized, permission-checked entity navigation in producers and
prove actual create/notify→personal list/count/visible action. Include legitimate queue
warnings in aggregate semantics and test healthy/warning/critical/unavailable source
combinations without weakening partial-read behavior.
