# Independent review: failed logout silently restores the account

Confirmed current frontend session-recovery defect; priorityP1 for shared
workstations, conditional high confidentiality impact. Requires a failed logout
request while the refresh cookie remains valid and subsequent access to the same
browser. This is not a remote authentication bypass or proof of an actual leak.

Root reviewed the complete `ui/logout-recovery.cjs` diagnostic, its final JSON,
the restored-account screenshot, and the current source chain:

- `frontend/src/api/auth.ts:206–209`: clears local tokens and broadcasts logout,
  then ignores rejection of the asynchronous cookie-clear request.
- `frontend/src/api/token.ts:230–232`: cookie-clear is the server logout POST;
  the browser cannot infer successful server revocation from local token clearing.
- `frontend/src/lib/storage.ts:40–47`: local generation and access/user state are
  cleared, with no persistent failed-logout intent preventing restoration.
- `frontend/src/features/auth/AuthProvider.tsx:225–232`: immediately marks the
  account unauthenticated and clears recovery error. Initial mount subsequently
  calls restoreCurrentSession, which refreshes the still-valid cookie.

Reproduction on the isolated current app: real synthetic-owner login; intercept
only `/api/auth/logout/` with503; click Account Logout. The UI navigates to/login
and displays the password form. Remove the failure interception and reload:
the same owner account is restored without credentials. Final receipt additionally
waits for the actual logout control and verifies the synthetic owner email.
The screenshot shows the authenticated Account page, not only a changed URL.
The diagnostic then performs ordinary logout for its own browser session.

Evidence: `ui/logout-recovery.json`, `ui/logout-503-restored.png`; the initial
pending-page observation is retained separately. No working DB, real account,
external provider or security probe by the independent reviewer was used.
The diagnostic's intended EN localStorage setting did not produce an EN screen;
the screenshot is RU. This does not invalidate the logout result but has been
reported for locale-matrix evidence correction.

Expected boundary: current access contract says ordinary tracked logout revokes
the current device. An unsuccessful request must not be presented as completed
logout while a reload silently restores access. A future fix must expose truthful
failure/retry behavior and preserve logout intent across reload/tab coordination
until server revocation succeeds, without storing credentials in browser storage.
Verify normal logout,503/offline/CSRF recovery, reload, cross-tab behavior, successful
retry and a subsequent explicit login. Do not silently revoke other devices.
No implementation or policy change was made by this audit.
