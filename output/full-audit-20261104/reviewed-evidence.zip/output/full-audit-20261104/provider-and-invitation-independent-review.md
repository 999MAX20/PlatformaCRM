# Independent source/contract review: provider paths and invitation validation

## Provider version drift

Root independently opened the official Ozon announcement and read the exact
current fetch_ozon_events paths. The June1,2026 announcement states August1,2026
retirement of v2 FBO list and v3 FBS list; both remain in current code. Replacement
paths are v3 FBO list and v4 FBS list. Confirmed contract drift, P2 for configured
Ozon sync; no authenticated seller request or observed live outage is claimed.
[Official announcement](https://dev.ozon.ru/news/734-Otkliuchenie-starykh-metodov-Seller-API-dlia-raboty-s-postingami/).

Root's direct WB fetch failed; the primary-domain search result returned the
March23,2026 release entry. It announces June23 retirement of supplier/stocks and
the replacement stocks-report/wb-warehouses. Current code still calls the old
path only when optional stocks is selected; defaults are orders and sales.
Confirmed source-versus-announced-contract drift, P2 for that option, not blanket
failure of all WB integration. [Official release notes](https://dev.wildberries.ru/en/release-notes?id=392).

Backend independently reviewed the same sources in
`backend/provider-protocol-review.md`. Acceptance requires current request/response
schemas, paging and error fixtures; credentials validation on another endpoint
does not certify sync. Live provider acceptance remains a separate environment
boundary. The quantity/warehouse fixture observations are not promoted to money
or stock corruption without the exact replacement protocol and downstream policy.

## Malformed invitation token returns500

Confirmed P2 functional input-validation defect. UI's isolated browser matrix
observed500 for preview/invalid; its backend log records Django UUID conversion
ValidationError. Root independently read the preview action and global exception
handler, and backend reviewer traced UUIDField and existing tests. The route
accepts any non-slash string, then filters the UUID field directly. The handler
maps DRF validation but treats this Django conversion exception as internal500.

A valid-shaped absent UUID reaches the explicit not-found validation path; an
expired real invitation has a separate status/acceptance contract. This finding
is distinct from prior UI06's unhelpful invalid-invitation form, though remediation
should cover the complete flow. Validate/parse token shape before lookup and
return stable4xx; verify malformed, absent, expired, revoked and valid states,
with truthful UI recovery and no obsolete acceptance form. No authorization
bypass or sensitive invitation disclosure is asserted; no new active auth probe
was run by the independent reviewers.
