# Backend helper cardinality evidence

These are query-shape observations on disposable SQLite with synthetic owned objects,
not production capacity or latency thresholds. Parent HTTP/PostgreSQL soak evidence
is separate in `../performance-results.md`. No privileged endpoint, provider or
working database was exercised. Measurements capture SQL count/size and wall time;
the same owner Python object and normal process caches are reused within each test.

`helper-performance-results.json` retains exact log lines and hashes. Initial batch:
branch slots and usage loop passed; notification fixture used an unrecognized URL
and failed0-versus1 before the other owned helpers. That failure remains in
`helper-performance.log`. Only the affected owned-helper test was rerun with the
recognized `/app/clients` route; `helper-performance-recheck.log` passed. No product
source was changed and no assertions were relaxed.

Observed boundaries:

- Platform list's exact usage-summary loop:11 SQL queries per business,11/110/275
  for1/10/25 businesses. This proves linear query growth in that component only.
- Branch slots with no existing bookings:9/15/31 queries for1/4/12-hour schedules,
  producing2/8/24 candidate slots. Conflict lookup is per candidate. Travel and
  occupied schedules were not benchmarked.
- Client card and limit10 work queue measured with1/20/100 linked overdue tasks.
  Query counts remain bounded after the page fills; all related domains were not
  populated. The card returns a dictionary, so `result_count` counts top-level keys.
- Visit-plan selector plus prefetched steps uses2 queries; full owner projection
  uses4 at each1/20/100-step fixture. No N+1 demonstrated for this combination.
- Notification first10 results use a bounded number of SQL queries while candidate
  IDs are materialized before page slicing. Source confirms full candidate scan;
  these100 rows do not establish a memory leak or outage.

Exact commands: `.venv/Scripts/python.exe -B output/full-audit-20261104/backend/run_functional_edges.py probe_performance_helpers`
(2 PASS,1 fixture FAIL, exit1), then the same command with
`probe_performance_helpers.HelperMeasurements.test_owned_helpers_cardinality`
(1 PASS, exit0). The runner suppresses dotenv and supplies a synthetic keyring;
isolated migrations/system checks are part of each disposable test database setup.
