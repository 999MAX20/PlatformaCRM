import ast
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

registry = json.loads((OUT / 'migration-registry.json').read_text(encoding='utf-8'))
tests = list(csv.DictReader((OUT.parent / 'backend-test-results.csv').open(encoding='utf-8')))
probe = ast.parse((OUT / 'probe_migration_acceptance.py').read_text(encoding='utf-8'))
cases = next(ast.literal_eval(n.value) for n in probe.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CASES' for t in n.targets))
case_paths = {f'apps/{app}/migrations/{name}.py': case for case, (app, name) in cases.items()}
existing = {
    'apps/ai_core/migrations/0008_customer_knowledge_visibility.py': 'apps.bots.tests_safety_migration.',
    'apps/integrations/migrations/0006_encrypt_plaintext_config_credentials.py': 'apps.integrations.tests_encrypted_config.EncryptedConfigBoundaryTests.test_data_migration_',
    'apps/notifications/migrations/0007_backfill_personal_recipients.py': 'apps.notifications.tests_personal_migration.',
    'apps/scheduling/migrations/0010_appointment_responsible_user_and_more.py': 'apps.scheduling.tests_record_migration.',
    'apps/tasks/migrations/0011_task_specialist_task_waiting_reason_and_more.py': 'apps.tasks.tests_migrations.',
}
log = (OUT / 'migration-acceptance.log').read_text(encoding='utf-8')
stage_log_path = OUT / 'migration-stage-recheck.log'
stage_log = stage_log_path.read_text(encoding='utf-8') if stage_log_path.exists() else ''
recovery_log_path = OUT / 'migration-recovery.log'
recovery_log = recovery_log_path.read_text(encoding='utf-8') if recovery_log_path.exists() else ''
recovery_cases = {
    'apps/ai_core/migrations/0008_customer_knowledge_visibility.py': ('ai_core', '0008_customer_knowledge_visibility', 'test_ai_knowledge_data_recovery'),
    'apps/notifications/migrations/0007_backfill_personal_recipients.py': ('notifications', '0007_backfill_personal_recipients', 'test_notification_recipient_data_recovery'),
}
rows = []
for source in registry:
    path = source['path']
    tree = ast.parse((ROOT / path).read_text(encoding='utf-8-sig'))
    depends = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'dependencies' for t in node.targets):
            depends = ast.unparse(node.value)
    operations = [o for o in source['operations'] if o['operation'] == 'migrations.RunPython']
    if not operations and path not in existing:
        continue
    prefix = existing.get(path)
    receipts = [r for r in tests if prefix and r['test_id'].startswith(prefix)]
    case = case_paths.get(path)
    recovery = recovery_cases.get(path)
    selected_log = stage_log if case == 'stage_canonical' else log
    passed = bool(case and f'MIGRATION_RECEIPT {case} populated-predecessor rollback-after-write retry replay PASS' in selected_log)
    if recovery:
        passed = f'MIGRATION_RECOVERY_RECEIPT {recovery[0]} {recovery[1]} populated rollback retry replay PASS' in recovery_log
    if case or recovery:
        status = 'PASS-populated-predecessor-failure-retry-replay' if passed else 'NOT-PASS-see-retained-log'
        gaps = ['SQLite only; no PostgreSQL DDL/lock/data-volume or process-kill acceptance.', 'Fault injected after RunPython data writes before migration completion; not an interruption at every individual row.']
    elif receipts:
        status = 'REUSED-scoped-existing-receipt'
        gaps = ['No data-write failure injection/rollback/retry receipt for this migration.']
        if 'integrations/' in path:
            gaps += ['Existing test calls function with current Django apps; not historical MigrationExecutor upgrade or missing-key/partial-encryption failure proof. No new protected security probe.']
        if 'ai_core/' in path:
            gaps += ['Visibility migration existing fixture only; no new protected security probe.']
    else:
        status = 'GAP-populated-upgrade-and-failure-evidence'
        gaps = ['Fresh empty-database migration success does not prove populated role/capability preservation, partial failure or rerun.', 'No new protected security probe; source/static and existing general permission tests do not replace a migration fixture.']
    rows.append({'path': path, 'source_sha256': sha(ROOT/path), 'registry_hash_matches': sha(ROOT/path) == source['sha256'], 'dependencies': depends,
                 'data_functions': [o['arguments'] for o in operations], 'status': status,
                 'new_test': f'probe_migration_recovery.OrdinaryMigrationRecovery.{recovery[2]}' if recovery else f'probe_migration_acceptance.MigrationAcceptance.test_{case}' if case else None,
                 'new_log': 'output/full-audit-20261104/backend/migration-recovery.log' if recovery else ('output/full-audit-20261104/backend/migration-stage-recheck.log' if case == 'stage_canonical' else 'output/full-audit-20261104/backend/migration-acceptance.log') if case else None,
                 'existing_receipts': receipts,
                 'existing_test_source_hashes_match': all(sha(ROOT/r['source']) == r['source_sha256'] for r in receipts),
                 'remaining_boundaries': gaps})
save('migration-acceptance-rows.json', rows)
summary = {
    'boundary': 'Migration graph predecessors are technical fixture states, not declared supported deployment release versions.',
    'supported_previous_release': None,
    'support_policy_search': ['docs/current/', 'docs/testing/testing.md', 'actual_docs/PROJECT_HANDOFF.md'],
    'support_policy_result': 'No explicit supported previous release/version matrix identified in selected operations/testing authority; do not invent one.',
    'registry_entries': len(registry), 'data_migrations': sum(bool(r['data_functions']) for r in rows),
    'additional_existing_schema_upgrade_rows': sum(not bool(r['data_functions']) for r in rows),
    'new_scenario_pass_count': sum(r['status'].startswith('PASS-') for r in rows),
    'zero_schema': {'receipt': 'output/full-audit-20261104/backend/migration-acceptance.log', 'boundary': 'Django creates isolated test database and applies entire current migration graph; no populated legacy release implied.'},
    'prior_zero_and_drift': 'Retain original full-backend/migration-drift receipts; failed application tests do not erase separately successful schema setup.',
    'initial_harness_failure': {'receipt': 'output/full-audit-20261104/backend/migration-acceptance-initial-harness-failure.log', 'boundary': 'First SQL-wrapper exception occurred inside model.save mark_for_rollback_on_error; SQLite schema-editor constraint check met broken transaction and contaminated remaining cases. Not product acceptance. Corrected injection happens after RunPython data writes return.'},
    'corrected_suite': {'receipt': 'output/full-audit-20261104/backend/migration-acceptance.log', 'result': '6 PASS / 1 fixture ERROR: missing required Deal.client before target migration executes.', 'reuse_boundary': 'Only the stage_canonical fixture changed afterward; other six cases and product/config inputs unchanged. Original probe snapshot retained.'},
    'stage_recheck': {'receipt': 'output/full-audit-20261104/backend/migration-stage-recheck.log', 'result': 'PASS' if 'MIGRATION_RECEIPT stage_canonical' in stage_log else 'not passed'},
    'ordinary_recovery_followup': {'receipt': 'output/full-audit-20261104/backend/migration-recovery.log', 'boundary': 'AI owned Inbox material and personal sent notification preservation only. No API/auth/role/identity probing; no new role/capability/credential migration scenario.'},
    'uncovered_data_migrations': [r['path'] for r in rows if r['status'].startswith('GAP-')],
    'no_failure_injection_receipts': [r['path'] for r in rows if r['data_functions'] and not r['status'].startswith('PASS-')],
    'all_source_hashes_match': all(r['registry_hash_matches'] for r in rows),
    'all_existing_test_source_hashes_match': all(r['existing_test_source_hashes_match'] for r in rows),
    'artifacts': [{'path': str(p.relative_to(ROOT)).replace('\\','/'), 'sha256': sha(p)} for p in [OUT/'migration-acceptance.log', OUT/'migration-acceptance-initial-harness-failure.log', OUT/'probe_migration_acceptance.py', OUT/'probe-migration-before-fixture-fix.txt', OUT/'migration-acceptance-rows.json', stage_log_path, recovery_log_path, OUT/'probe_migration_recovery.py'] if p.exists()],
}
save('migration-acceptance-summary.json', summary)
print(json.dumps({k: summary[k] for k in ['registry_entries','data_migrations','new_scenario_pass_count','all_source_hashes_match','uncovered_data_migrations']}, ensure_ascii=False))
