# Provider protocol review — 2026-11-04

Only public primary documentation was consulted. No provider credentials, seller API requests or live syncs were used.

## Ozon posting API versions

The official announcement dated2026-06-01 postponed retirement of `/v2/posting/fbo/list` and `/v3/posting/fbs/list` to2026-08-01 and names replacements `/v3/posting/fbo/list` and `/v4/posting/fbs/list`. [Official Ozon announcement](https://dev.ozon.ru/news/734-Otkliuchenie-starykh-metodov-Seller-API-dlia-raboty-s-postingami/).

Current `apps/integrations/ozon/base.py:113` still uses the retired FBS path and line126 the retired FBO path. Credential validation uses a different warehouse endpoint (`:65`), so validation success does not prove these sync paths work. This is confirmed source-versus-announced-contract drift at the audit date, not an observed live HTTP failure. Proposal: P2 for enabled Ozon sync; update request/response adapters and pagination against current official schemas, add recorded fixture tests, then separately authorize live read-only acceptance.

## Wildberries optional stocks path

The official2026-03-23 release entry announces replacement POST `/api/analytics/v1/stocks-report/wb-warehouses`, warehouse-specific inventory rows, offset pagination and retirement of GET `/api/v1/supplier/stocks` onJune23. [Official WB release notes](https://dev.wildberries.ru/en/release-notes?id=392).

Current `apps/integrations/wildberries/base.py:110–111` still calls the old stocks path whenever stocks is selected. Defaults include orders/sales only (`:42–50`), so this specifically affects the optional stocks configuration; it is not a blanket failure of default WB sync. The safe-config note says replacement is not finalized, which is stale against the official announcement. No live endpoint behavior was measured.

## Unresolved transform assumptions

The isolated fixture proves Ozon `_posting_amount` ignores quantity and WB stock events use barcode-only external identity across warehouses. It does not by itself establish price-per-unit semantics or the downstream product requirement for warehouse aggregation. Official Ozon schema pages returned empty content/timeouts; official WB old schema pages returned fetch errors. Community examples and third-party schema mirrors were not treated as authoritative contracts. Preserve these as explicit protocol/effect gaps until current replacement schemas and downstream event semantics are reconciled; do not label the fixture alone a verified financial/stock defect.
