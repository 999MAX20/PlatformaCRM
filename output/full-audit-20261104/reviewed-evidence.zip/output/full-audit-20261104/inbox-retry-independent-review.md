# Independent review: Inbox retry identity across conversations

Confirmed current client retry-identity defect, P2; duplicate provider delivery is
a conditional consequence, not an observed external event. Root independently
read the complete hook probe/result, actual useInboxSending and useInboxDraft,
the Inbox POST action, send_outbound_message, create_outbound_message and database
uniqueness constraints. Backend reviewer independently traced the same chain.

The hook stores one send key for all conversations. After an uncertain response
in A, an immediate unchanged A retry preserves the key. Sending B replaces that
single ref; B success clears it. Returning to the retained unchanged A draft
creates a new key. The executable probe runs actual transpiled hook code with
deterministic useRef/useMutation adapters. It has no network and does not simulate
a complete React browser lifecycle; UI integration follow-up remains separate.

Draft storage is per actor/Business/conversation, so A's unsent text can survive
the switch. The actual API forwards Idempotency-Key to the outbox. Server lookup
and uniqueness use conversation+key. request_hash is compared only after finding
the same key; there is no independent text/draft deduplication. If the first A
request committed before its response was lost, the new key can create another
queued BotMessage and schedule another provider intent. Equal text can also be a
deliberate new message, so indiscriminate text deduplication is not a safe fix.

Keep retry identity with the specific unresolved draft/action until its outcome
is reconciled, including conversation switch, reload/storage failure and success
of other sends. Verify committed-response-loss versus rejected-before-commit,
same-A retry, A/B/A switching, draft edits, explicit new message and successful
clearing. Preserve actor/Business isolation and server same-key mismatch checks.

Evidence: `ui/inbox-idempotency-validation.cjs` and `.json`; current source hash
recorded there. No product change, external message or real-account action was
performed by this proof or independent review.
