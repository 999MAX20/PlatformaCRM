# Independent review: worker progress and stale completion

Root consumed complete backend/probe_remaining_functional.py and final14 lines of
remaining-functional-observations.log (5 observation tests pass). Source review:
apps/businesses/routing.py188–237; apps/automations/engine.py394–448;
apps/bots/outbound_delivery.py1–245,260–334,388–437.

- **Routing starvation, P2 confirmed.** route_unassigned_work consumes the global
  checked budget even when no member can receive the item. Each cycle begins with
  the same policies/oldest unassigned IDs; enough permanently unassignable items
  prevent later eligible work from being considered. Three limit1 cycles leave
  the later business unassigned; limit2 assigns it. Default-limit reachability
  requires enough blocked items to consume100, not merely the two-row fixture.
- **Overdue automation starvation, P2 confirmed.** The scanner slices overdue tasks
  before creating/reusing event runs; processed but still-overdue tasks remain in
  the slice. Three limit1 scans create only one run; limit2 reaches the second.
  Broker scheduling alone is mocked. Equivalent default-limit backlog threshold
  is100; this is missing progress under persistent backlog, not a duplicate run.
- **Generic outbound stale completion, P2 confirmed.** Claim/recovery have no
  per-attempt fencing token. _finish_delivery saves a stale instance by primary key
  after a newer claim succeeds. Real ORM interleaving changes sent back to
  retry_scheduled. Recovery may therefore retry an already successful delivery.
  No provider call or real duplicate delivery occurred. YCloud transport returns
  early and uses its own durable attempt handling; this finding is about generic
  delivery. Manager conversation locking does not establish message claim identity.

The two pricing observations remain separate pending policy review: repeated
approval produces two simulated logs; an available365-day-old cheap offer is used
instead of a newer higher offer. The latter has no established freshness threshold
in the supplied contract and is not promoted to an unconditional defect here.

Acceptance proposals: prove progress past a full batch of ineligible/already-processed
records without losing idempotency; fence generic delivery completion by the exact
claim and reject stale finalizers. Validate concurrent execution in PostgreSQL when
fixing, beyond these deterministic scheduling-point reproductions.
