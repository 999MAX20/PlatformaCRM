# Independent review of functional boundary reproductions

Root read the complete probe and runner, final observations and retained fixture
failure, plus the relevant current implementation bodies. Baseline d27044b1 with
recorded WIP; no product edits or second runtime execution by root. The runner
suppresses working dotenv, uses disposable SQLite/files and guarded sockets.
The original run had ten successful observation assertions and one fixture error
(`Lead.title` does not exist). Only that fixture was corrected; the separate lead
recheck passed. These assertions reproduce existing defects, not acceptance PASS.

| Case | Independent disposition and acceptance |
| --- | --- |
| EXPORT-STALE-COMPLETION | Confirmed P2. Real ORM claim and actual process_export_job run twice with deterministic interleaving; renderer alone supplies OLD/NEW and ages the first claim. A successor saves NEW, then the old worker overwrites the job with OLD. Final save and exception save lack a claim token/started_at condition. Fence both success and failure by the active claim and clean up superseded files. Add actual PostgreSQL competing-worker proof before remediation acceptance; present evidence is not concurrent-process certification. |
| EXPORT-WORKER-ROW-LIMIT | Confirmed P2 missing generation-time limit. Enqueue enforces the configured maximum and states that export cannot exceed it; the worker queries current data again without rechecking. One row at enqueue/max1 becomes two exported rows after growth. This proves bound bypass in ordinary timing, not production memory exhaustion. Recheck the effective source bound during generation and define truthful failure/retry without partial files. |
| EXPORT-QUOTED-NEWLINE-COUNT | Confirmed P3 metadata defect. The service counts newline bytes; a quoted newline in one client's name yields two reported records although csv.reader returns one. Exported content is valid. Count records during generation or use a CSV-aware result count; verify quoted multiline cells and empty files. |
| UTF8-PREFIX-REJECTION | Confirmed P2. File validation decodes a fixed512-byte prefix as a complete UTF-8 string. A valid two-byte character across the boundary fails; the aligned control passes. Validate with an incremental decoder or a complete bounded text check while retaining signature/AV/size protections; test multibyte boundaries and genuinely invalid sequences. |
| TASK-INVALID-CALENDAR-500 | Confirmed P2. parse_datetime can raise for an impossible date, while the view handles only a None result. Same-owner list request gets500 for February31 and400 for malformed text. Return field validation errors for both date syntax and value errors; include due_from/due_to. |
| REPORT-INVALID-CALENDAR-500 | Confirmed P2 in the exercised report route. Shared date-range helper similarly assumes parse_date returns None for all invalid input. February31 causes500 while malformed text returns400. Cover start/end, range limits and representative callers; no claim every caller was dynamically exercised. |
| WORKING-HOURS-WEEKDAY-500 | Confirmed P2. The bulk endpoint constructs set(weekdays) and queries before serializer type validation. A nested list weekday raises TypeError; weekday0 control succeeds. Validate scalar integer range and duplicates before lookup; invalid batches must leave all hours unchanged. |
| SEGMENT-TAG-EMPTY | Confirmed P2. Tag handling runs before generic empty predicates. With no tag value, is_empty returns the entire client queryset and not_empty returns none, regardless of actual tagged objects. One tagged/one untagged fixture yields2/0 instead of1/1. Correct existence semantics with Business scoping and test no tags, multiple tags, archived clients and both operators. No source-permission bypass is asserted by this proof. |
| LEAD-REOPEN-APPOINTMENT-STATE | Confirmed functional inconsistency, P2. The real domain path can close appointment_created as lost and save that previous state. reopen chooses it, but the terminal transition table rejects it; actual API returns409. A valid reopen target needs contract-consistent fallback or an explicitly supported prior-state transition. Do not automatically reopen or mutate an Appointment as part of this remedy. Exact target policy remains a scoped decision if not resolved by existing lifecycle rules. |

`backend/functional-edge-findings.json` links source hashes, test methods and exact
log lines. Import numeric helpers and Ozon/Wildberries fixture transforms remain
separate observations pending endpoint/provider-contract reconciliation; their
presence in this test run is not sufficient to declare production money corruption.
