import csv
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
load = lambda name: json.loads((OUT / (name + '.json')).read_text(encoding='utf-8'))
errors = []
tables = {name: load(name) for name in ['behavior-node-registry','api-operation-matrix','api-behavior-links','state-transition-sites','transition-table-registry','event-evidence-matrix','effect-site-registry','role-action-scope-matrix','job-evidence-matrix']}
ids = {}
for name, rows in tables.items():
    counts = Counter(row['id'] for row in rows)
    duplicates = {key: count for key, count in counts.items() if count > 1}
    if duplicates:
        errors.append({'table': name, 'duplicate_ids': duplicates})
    ids[name] = set(counts)
test_ids = {row['test_id'] for row in csv.DictReader((OUT.parent / 'backend-test-results.csv').open(encoding='utf-8'))}
line_counts = {}

def check_location(location, context):
    path, line = location.get('path'), location.get('line')
    if not path:
        return
    absolute = ROOT / path
    if not absolute.is_file():
        errors.append({'context': context, 'missing_source': path})
    elif line:
        if path not in line_counts:
            line_counts[path] = len(absolute.read_text(encoding='utf-8-sig').splitlines())
        if not 1 <= line <= line_counts[path]:
            errors.append({'context': context, 'invalid_line': line, 'path': path})

def links(values, target, context):
    missing = set(values) - target
    if missing:
        errors.append({'context': context, 'missing_refs': sorted(missing)})

for node in tables['behavior-node-registry']:
    check_location(node, node['id'])
    links([call['target'] for call in node['calls']], ids['behavior-node-registry'], node['id'])
    links(node['state_mutation_ids'], ids['state-transition-sites'], node['id'])
    links(node['event_site_ids'], ids['event-evidence-matrix'], node['id'])
    links(node['direct_executed_test_ids'], test_ids, node['id'])
    links(node.get('persistence_or_external_effect_ids', []), ids['effect-site-registry'], node['id'])
    if not (ROOT / node['requirement_authority']).is_file():
        errors.append({'context': node['id'], 'missing_authority': node['requirement_authority']})
for operation in tables['api-behavior-links']:
    check_location(operation['handler_location'], operation['id'])
    for hook in operation['resolved_hooks'].values():
        check_location(hook['location'], operation['id'])
    links(operation['process_node_ids'], ids['behavior-node-registry'], operation['id'])
    links(operation['state_mutation_ids'], ids['state-transition-sites'], operation['id'])
    links(operation['event_site_ids'], ids['event-evidence-matrix'], operation['id'])
    links(operation['literal_request_test_ids'] + operation['direct_callee_test_ids'], test_ids, operation['id'])
    links(operation.get('persistence_or_external_effect_ids', []), ids['effect-site-registry'], operation['id'])
    links(operation.get('default_role_preset_row_ids', []), ids['role-action-scope-matrix'], operation['id'])
    for check in operation.get('explicit_resource_action_checks', []):
        links(check['role_preset_row_ids'], ids['role-action-scope-matrix'], operation['id'])
    if not operation['process_node_ids'] and not operation['concrete_gaps']:
        errors.append({'context': operation['id'], 'error': 'no behavior links or explicit gaps'})
for name in ['state-transition-sites','transition-table-registry','event-evidence-matrix']:
    for row in tables[name]:
        check_location(row, row['id'])
if ids['api-operation-matrix'] != ids['api-behavior-links']:
    errors.append({'error': 'operation identity mismatch'})
for effect in tables['effect-site-registry']:
    check_location(effect, effect['id'])
    links([effect['behavior_node_id']], ids['behavior-node-registry'], effect['id'])
    if effect.get('event_site_id'):
        links([effect['event_site_id']], ids['event-evidence-matrix'], effect['id'])
for job in tables['job-evidence-matrix']:
    check_location(job, job['id'])
    links(job['process_node_ids'], ids['behavior-node-registry'], job['id'])
    links(job['state_mutation_ids'], ids['state-transition-sites'], job['id'])
    links(job['event_site_ids'], ids['event-evidence-matrix'], job['id'])
    links(job['persistence_or_external_effect_ids'], ids['effect-site-registry'], job['id'])
    links(job['direct_callee_test_ids'], test_ids, job['id'])
log_lines = {}
for row in load('test-assertion-matrix'):
    execution = row['execution']
    check_location({'path': execution['method_source'], 'line': int(execution['method_line'])}, row['test_id'])
    evidence = ROOT / execution['evidence']
    if not evidence.is_file():
        errors.append({'context': row['test_id'], 'missing_log': str(evidence)})
    else:
        if str(evidence) not in log_lines:
            # Historical Windows logs mix encodings; ASCII test IDs remain exact.
            log_lines[str(evidence)] = [line.decode('utf-8', errors='replace') for line in evidence.read_bytes().split(b'\n')]
        line = int(execution['log_line'])
        content = log_lines[str(evidence)]
        if not 1 <= line <= len(content) or row['test_id'].split('.')[-1] not in content[line - 1]:
            errors.append({'context': row['test_id'], 'invalid_log_line': line, 'log': execution['evidence']})
summary = {'table_rows': {name: len(rows) for name, rows in tables.items()}, 'test_result_ids': len(test_ids),
    'referenced_source_files_checked': len(line_counts), 'errors': errors,
    'boundary': 'ID/source-range/log existence and referential integrity. Assertions/graph semantics are reviewed separately; no new product runtime certification.'}
(OUT / 'behavior-link-validation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({**summary, 'errors': errors[:5], 'error_count': len(errors)}, ensure_ascii=False))
raise SystemExit(bool(errors))
