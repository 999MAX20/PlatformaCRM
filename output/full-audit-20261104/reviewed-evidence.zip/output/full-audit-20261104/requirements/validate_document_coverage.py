import json,hashlib,collections
from pathlib import Path
from document_snapshot import snapshot_bytes
OUT=Path('output/full-audit-20261104/requirements')
p=OUT/'document-ledger.json';rows=json.loads(p.read_text(encoding='utf8'));by={x['path']:x for x in rows};errors=[];cache={};counts=collections.Counter();details=[]
assert len(by)==len(rows),'duplicate path'
def source(path):
 if path not in cache:
  raw,_=snapshot_bytes(path);cache[path]=(hashlib.sha256(raw).hexdigest(),raw.decode('utf-8-sig').splitlines())
 return cache[path]
def span(a,b):return set(range(a,b+1))
def direct(row):
 if row.get('equivalence_source'):return set()
 return {n for a,b in row['read_ranges'] for n in range(a,b+1)}
for row in rows:
 path=row['path'];sha,lines=source(path);n=row['line_count'];d=direct(row);equiv=set();generated=set();local=[]
 if sha!=row['sha256']:local.append('current SHA differs from reviewed snapshot')
 if len(lines)!=n:local.append('line count differs')
 if not d<=span(1,n):local.append('direct range out of bounds')
 alias=row.get('equivalence_source') or row.get('equivalent_to')
 if alias:
  src_sha,src_lines=source(alias);sr=by[alias]
  if sha!=src_sha or lines!=src_lines:local.append('whole-file SHA alias no longer exact')
  if direct(sr)!=span(1,sr['line_count']):local.append('whole-file alias source not fully directly read')
  equiv.update(span(1,n));counts['whole_file_aliases']+=1
 for block in row.get('equivalent_blocks',[]):
  sp=block['source_path'];src_sha,src_lines=source(sp);a,b=block['source_start'],block['source_end'];ta,tb=block['target_start'],block['target_end']
  if sp==path:local.append('self equivalence reference')
  if src_sha!=block['source_sha256'] or sha!=block['target_sha256']:local.append('block source/target SHA mismatch')
  if not span(a,b)<=direct(by[sp]):local.append('block source has non-direct line or alias chain')
  if not span(ta,tb)<=span(1,n):local.append('target block out of bounds')
  if 'source_json_pointer' in block:
   value=json.loads(Path(sp).read_text(encoding='utf8'))
   for bit in block['source_json_pointer'].split('/')[1:]:
    key=bit.replace('~1','/').replace('~0','~');value=value[int(key)] if isinstance(value,list) else value[key]
   if not isinstance(value,str):local.append('JSON pointer is not string');content=[]
   else:content=value.splitlines()
  else:content=src_lines[a-1:b]
  if content!=lines[ta-1:tb]:local.append('decoded block equality failed')
  if hashlib.sha256('\n'.join(content).encode('utf8')).hexdigest()!=block['line_block_sha256']:local.append('block digest mismatch')
  equiv.update(span(ta,tb));counts['validated_exact_blocks']+=1
 if row.get('generated_validation'):
  receipt=json.loads(Path(row['generated_validation']).read_text(encoding='utf8'))
  if receipt['path']!=path or receipt['sha256']!=sha:local.append('generated receipt SHA mismatch')
  if receipt.get('schema_unique_paths_hash_format')!='PASS':local.append('generated schema not PASS')
  generated.update(span(1,n))
 for item in row.get('generated_metadata_ranges',[]):
  receipt=json.loads(Path(item['receipt']).read_text(encoding='utf8'))
  if receipt['path']!=path or receipt['sha256']!=sha:local.append('generated range receipt SHA mismatch')
  if [item['start'],item['end']] not in receipt['ranges']:local.append('generated range not certified')
  generated.update(span(item['start'],item['end']))
 covered=d|equiv|generated;missing=sorted(span(1,n)-covered)
 if missing:local.append('uncovered lines: '+str(missing[:20]))
 if row.get('context_review_status')!='reviewed' or not row.get('context_disposition'):local.append('context disposition missing')
 counts['files']+=1;counts['total_lines']+=n;counts['direct_unique_lines']+=len(d);counts['equivalent_only_lines']+=len(equiv-d);counts['generated_only_lines']+=len(generated-d-equiv)
 depth='direct-full-text' if len(d)==n else 'direct-and-exact-equivalence' if not generated else 'semantic-text-plus-validated-generated-metadata'
 counts[depth]+=1
 details.append({'path':path,'sha256':sha,'lines':n,'direct_lines':len(d),'exact_equivalent_only_lines':len(equiv-d),'generated_only_lines':len(generated-d-equiv),'coverage_depth':depth,'status':'PASS' if not local else 'FAIL','errors':local})
 if local:errors.append({'path':path,'errors':local})
 else:
  row.setdefault('legacy_reader_status',row['status']);row['status']='fully-reviewed';row['content_coverage_status']='complete';row['coverage_depth']=depth
result={'status':'PASS' if not errors else 'FAIL','boundary':'All assigned document text is covered by actual direct ACK ranges or exact SHA/decoded-block equivalence from directly read sources; generated metadata is independently validated. Exact equivalence is not counted as direct rereading. Every distinct file has contextual historical/current disposition.','counts':dict(counts),'errors':errors,'files':details}
if (OUT/'document-delta-review.json').is_file():result['current_docs_delta']='output/full-audit-20261104/requirements/document-delta-review.json; original source SHA/line coordinates retained, known parent delta independently read and SHA-validated'
(OUT/'document-coverage-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
if not errors:p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
print(result['status']);print(dict(counts));print(json.dumps(errors,ensure_ascii=True)[:4000])
