# Timeline grouping uses a different timezone from its timestamps

Confirmed P2 presentation/correctness defect when browser and Business timezones
differ near a date boundary. Root read the complete current diagnostic and JSON
receipt, timelineHelpers.ts236–248, format.ts1–125, complete timeline.tsx and
EntityTimeline.tsx, and the useBusiness setter references. The direct caller
groups the same data.timeline events and renders each created_at using the common
formatter, so the tested helpers are connected to the reachable entity timeline.

`groupTimeline` uses Intl.DateTimeFormat without timeZone, therefore browser local
time. `formatDateTime` defaults to the active Business timezone. The diagnostic
executes both unchanged functions with process TZ=UTC and Business Asia/Almaty:
2026-01-01T20:30Z groups under January01 but its timestamp displays January02 01:30.
Only icon imports are stubbed; date calculations are not mocked. This is actual
function execution plus source reachability, not a newly executed browser screenshot.

The timestamp's Russian locale in an English group is covered by the existing
default-locale finding family; the wrong day grouping is a distinct consequence.
No stored timestamp, appointment schedule, financial period or backend ordering
was changed or shown corrupt. With matching browser/Business zones the mismatch
does not arise for this case.

Future acceptance: group day keys and visible timestamps use the same explicit
Business timezone and selected locale; check opposite UTC offsets, both sides of
midnight, month/year boundaries and business switching without stale grouping.
Keep source timestamps untouched. Evidence: ui/timeline-timezone-validation.json
with source hashes and ui/timeline-timezone-validation.cjs.
